<div class="sidebar" data-color="purple" data-background-color="white" data-image="{{asset('asset/assets/img/sidebar-1.jpg')}}">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="{{route('subscriber-dashboard')}}" class="simple-text logo-normal">
            <img src="{{asset('asset/images/logo.png')}}">
        </a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav">
        @if(Auth::user()->is_admin=='2')
                <li class="nav-item @if(Request::path() =='subadmin/home')
                        active
                    @endif">
                    <a class="nav-link" href="{{route('subadmin.home')}}">
                        <i class="material-icons">dashboard</i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item @if(Request::path() =='sub/subsubscriberlist')
                        active
                    @endif">
                    <a class="nav-link" href="{{route('sub.userlist')}}">
                        <i class="material-icons">person</i>
                        <p>Non Subscriber</p>
                    </a>
                </li>
                <li class="nav-item @if(Request::path() =='sub/subscriber/subscriberlist')
                        active
                        @endif">
                    <a class="nav-link" href="{{route('sub.subscriberlist')}}">
                        <i class="material-icons">person</i>
                        <p>Active list</p>
                    </a>
                </li>


            <li class="nav-item @if(Request::path() =='admin/subscriber/paidsubscriberlist')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.paidsubscriberlist')}}">
                    <i class="material-icons">people</i>
                    <p>Subscriber List</p>
                </a>
            </li>

                <li class="nav-item @if(Request::path() =='admin/subscriber/pendinglist')
                        active
                        @endif">
                    <a class="nav-link" href="{{route('admin.pendinglist')}}">
                        <i class="material-icons">timer</i>
                        <p>Pending Subscriber </p>
                    </a>
                </li>
                <li class="nav-item @if(Request::path() =='admin/subscriber/rejectedlist')
                        active
                        @endif">
                    <a class="nav-link" href="{{route('admin.rejectedlist')}}">
                        <i class="material-icons">clear</i>
                        <p>Rejected List </p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                        <i class="material-icons">language</i>
                        <p>logout</p>
                    </a>
                </li>
        @else

        <li class="nav-item @if(Request::path() =='admin/userlist')
                active
            @endif">
            <a class="nav-link" href="{{route('admin.userlist')}}">
                <i class="material-icons">face</i>
                <p>All User (NonSub+Sub) </p>
            </a>
        </li>
        <li class="nav-item ">


                <ul class="submenu-super">


                </ul>
            </li>



            <li class="nav-item @if(Request::path() =='admin/subscriber/notice')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.notice')}}">
                    <i class="material-icons">note</i>
                    <p>Notice </p>
                </a>
            </li>




            <li class="nav-item @if(Request::path() =='admin/subscriber/subscription')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.subscription.fee')}}">
                    <i class="material-icons">receipt</i>
                    <p>Subscription Fee </p>
                </a>
            </li>

            <li class="nav-item @if(Request::path() =='admin/subscriber/seminar')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.seminar')}}">
                    <i class="material-icons">work</i>
                    <p>Training/ Seminar/ Workshop </p>
                </a>
            </li>


            <li class="nav-item @if(Request::path() =='admin/report')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.report')}}">
                    <i class="material-icons">assignment</i>
                    <p>Report</p>
                </a>
            </li>

            <li class="nav-item @if(Request::path() =='admin/subscriber/notice')
                    active
                @endif">
                <a class="nav-link" href="{{route('admin.settings')}}">
                    <i class="material-icons">face</i>
                    <p>Admin Settings </p>
                </a>
            </li>


        @endif


        </ul>
    </div>

</div>