<p>Hi, Your Subscriber Number is {{ $data['subscriber_number'] }}</p>
<br>



You can reset your password from this <a href="http://weforumbd.org/password/reset">link</a>
<br><br>

{{--<a href="http://weforumbd.org/verify?code={{$email_data['verification_code']}}">Click Here!</a>--}}

<br><br>
Thank you!
<br>
weforumbd.org