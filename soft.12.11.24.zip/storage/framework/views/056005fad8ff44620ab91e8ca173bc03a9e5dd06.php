
<?php $__env->startSection('title'); ?>
    <title><?php echo e($notice->title); ?> | Notice | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title"><?php echo e($notice->title); ?></h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "><?php echo e($notice->publishdate); ?> </small></legend>
                            <?php echo $notice->description; ?>

                        </fieldset>
                    </div>
                </div>



            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\22.3.21\20.3.21\resources\views/superadmin/notice/details.blade.php ENDPATH**/ ?>