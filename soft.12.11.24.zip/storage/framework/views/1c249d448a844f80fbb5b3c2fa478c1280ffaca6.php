
<?php $__env->startSection('title'); ?>
    <title>Seminar | Non-Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('nonsubscriber.redirection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">


                    <div class="card-header card-header-primary">
                        <h4 class="card-title">All Seminar/Workshop/Training</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>


                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "> </small></legend>

                            

                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            

                            

                            <?php $__currentLoopData = $seminar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(($seminar->eventdate) > (date('Y-m-d'))): ?>
                                <a href="<?php echo e(route('non-Subscriber_seminar_details',$seminar->id)); ?>">
                                    <div class="col-md-12 mb-12 mb-6">
                                        <div class="alert alert-info alert-info-custom">
                                            <?php $__currentLoopData = $seminar_fees_submit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminarfee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($seminar->id == $seminarfee->seminar_id): ?>
                                                    <a class="btn btn-xs danger pull-right btn-custom-seminar">
                                                        Paid
                                                    </a>
                                                <?php else: ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($seminar->title); ?> <strong style="color: #8e24aa; float: right; padding-right: 25px">  (<?php echo e($seminar->feegeneral); ?> Tk.) </strong>

                                        </div>
                                    </div>
                                </a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-row">


                                

                                
                                
                                
                                
                                
                                
                                
                                

                                


                            </div>

                        </fieldset>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\4.2.22\resources\views/nonsubscriber/Seminar.blade.php ENDPATH**/ ?>