<!-- Sidebar -->
<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('/')); ?>asset/assets/img/sidebar-1.jpg">
    
    
    
    
    

    <div class="sidebar-wrapper">
        <div class="page-wrapper chiller-theme toggled">

            <nav id="sidebar" class="sidebar-wrapper">
                <div class="logo">
                    <a href="<?php echo e(route('admin.home')); ?>" class="simple-text logo-normal">
                        <img src="<?php echo e(asset('/')); ?>asset/images/logo.png">
                    </a>
                </div>
                <div class="sidebar-content">

                    <div class="sidebar-menu">
                        <ul>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Setting</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('warehouse.index')); ?>">Wearhouse </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('unit.index')); ?>">Unit Type</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('purchasecompany.index')); ?>">Purchase Company Name</a>
                                        </li>

                                    </ul>
                                </div>
                            </li>


                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Product</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>



                                        <li>
                                            <a href="<?php echo e(route('category.index')); ?>">All Category</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('product.index')); ?>">All Product</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>
                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Warehouse</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <?php $__currentLoopData = \App\Models\Warehouse::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('warehouse.show',$warehouse->id)); ?>"><?php echo e($warehouse->name); ?></a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Company Stock</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('companyproduct.create')); ?>">Add Company Stock</a>
                                        </li>

                                        <li>
                                            <a href="<?php echo e(route('companyproduct.index')); ?>">All Company Stock</a>
                                        </li>
                                    <?php $__currentLoopData = \App\Models\Purchasecompany::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchaseCompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('purchasecompany.show',$purchaseCompany->id)); ?>"><?php echo e($purchaseCompany->name); ?> Company Stock</a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </li>

                            <li>
                                <a href="order-list.html">
                                    <i class="fa fa-globe"></i>
                                    <span>Order List</span>
                                </a>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>SR</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="sr-registration.html">SR Registration</a>
                                        </li>
                                        <li>
                                            <a href="all-sr-list.html">All SR List</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>


                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>SR Client</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>

                                        <li>
                                            <a href="all-shop-list.html">View SR Client</a>
                                        </li>

                                    </ul>
                                </div>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Purchase Client</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="add-purchase-client.html">Add Purchase Client</a>
                                        </li>
                                        <li>
                                            <a href="all-purchase-client.html">View Purchase Client</a>
                                        </li>

                                    </ul>
                                </div>
                            </li>


                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Income & Expense</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="add-income.html">Add Income</a>
                                        </li>
                                        <li>
                                            <a href="add-expense.html">Add Expense</a>
                                        </li>

                                        <li>
                                            <a href="view-income-&-expense.html">View Income & Expense</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>


                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Rent</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <li>
                                            <a href="driver-registration.html">Driver Registration</a>
                                        </li>
                                        <li>
                                            <a href="all-driver-list.html">All Driver List</a>
                                        </li>

                                        <li>
                                            <a href="add-road.html">Add Road</a>
                                        </li>

                                        <li>
                                            <a href="rent-income.htmls">Income/ Expense</a>
                                        </li>
                                    </ul>
                                </div>
                            </li>

                            <li>
                                <a href="invoice.html">
                                    <i class="fa fa-globe"></i>
                                    <span>Invoice</span>
                                </a>
                            </li>


                            <li>
                                <a href="order-list.html">
                                    <i class="fa fa-globe"></i>
                                    <span>Report</span>
                                </a>
                            </li>

                        </ul>
                    </div>
                    <!-- sidebar-menu  -->
                </div>

            </nav>
        </div>
    </div>
</div>
<!-- Side Bar -->

<?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\9.10.24\resources\views/layouts/partial/super/sidebar.blade.php ENDPATH**/ ?>