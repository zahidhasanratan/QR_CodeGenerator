
<?php $__env->startSection('title'); ?>
    <title>Seminar Details | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">

                    <div class="card-header card-header-primary">
                        <h4 class="card-title"> Renew for Next 1 Year</h4>
                        
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>

                    <div class="card-body">
                        <div class="col-lg-12 col-md-12">
                            <div class="seminar-workshop-box">

                                <!--<h4 class="seminar-fee"> Fee: <?php echo e($subscriptions->fees); ?> Tk.</h4>-->
                                
                                
                                <h4 class="seminar-fee"> Fee: 2040 Tk.</h4>
                                
                                
                                
                                <?php echo $subscriptions->description; ?>

                                <br>


                            </div>
                        </div>

                        <div class="form-group col-lg-12 text-center">
                            
                            <form method="POST" action="<?php echo e(route('nonsub_shurjopay-submission')); ?>">
                                <?php echo csrf_field(); ?>
                                <input name="userid" type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control">
                                <input name="subscriptionid" type="hidden" value="<?php echo e($subscriptions->id); ?>" class="form-control">
                                <input name="name" type="hidden" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                                <input name="email" type="hidden" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                                <input name="amount" type="hidden" value="2040" class="form-control">
                                <input name="year" type="hidden" value="<?php echo e($subscriptions->year); ?>" class="form-control">
                                

                                <?php if($subscriber->subscriber_number ==''): ?>

                                 <input name="subscriber_number" type="hidden" value="WE-SB-<?php echo e(substr($subscriber->country,0,3)); ?>-<?php echo e(Auth::user()->id); ?>" class="form-control">            
                                <?php else: ?>
                                
                                
                                <input name="subscriber_number" type="hidden" value="<?php echo e($subscriber->subscriber_number); ?>" class="form-control">
                    
                               
                                <?php endif; ?>



                                <button type="submit" class="btn btn-primary"><span>Pay Now</span></button>

                            </form>


                        </div>
                    </div>






                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/weforumbd/public_html/resources/views/nonsubscriber/nonSubscribe_subscription_details_renew.blade.php ENDPATH**/ ?>