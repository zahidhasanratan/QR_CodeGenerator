
<?php $__env->startSection('title'); ?>
    <title>Subscription Fees Details | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <?php $__currentLoopData = $subscription_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription_fees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card-header card-header-primary">
                        <h4 class="card-title"> <?php echo e($subscription_fees->title); ?> for <?php echo e(now()->year); ?></h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>


                    <div class="card-body">
                        <div class="col-lg-12 col-md-12">
                            <div class="seminar-workshop-box">
                                <h3 class="seminar-title-name"> <?php echo e($subscription_fees->title); ?> for <?php echo e(now()->year); ?> </h3>


                                <h4 class="seminar-fee"> Fee: <?php echo e($subscription_fees->fees); ?> Tk.</h4>
                                <?php echo $subscription_fees->description; ?>


                            </div>
                        </div>

                        <div class="form-group col-lg-12 text-center">

                            <form method="POST" action="<?php echo e(route('subscription-payment-submission')); ?>">
                                <?php echo csrf_field(); ?>
                                <input name="userid" type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control">
                                <input name="name" type="hidden" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                                <input name="email" type="hidden" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                                <input name="amount" type="hidden" value="2000" class="form-control">
                                <input name="year" type="hidden" value="<?php echo e(now()->year); ?>" class="form-control">
                                <button type="submit" class="btn btn-primary"><span>Pay Now</span></button>
                            </form>

                        </div>
                    </div>

                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.1.21\Software\WE\resources\views/subscriber/Subscribe_payement_details.blade.php ENDPATH**/ ?>