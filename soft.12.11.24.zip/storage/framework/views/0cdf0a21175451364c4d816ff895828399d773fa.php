
<?php $__env->startSection('title'); ?>
    <title>Dashboard | Super Admin | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-warning card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">content_copy</i>
                            </div>
                            <p class="card-category">Total Income</p>
                            <h3 class="card-title">20000
                                <small>tk</small>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="">view More...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">store</i>
                            </div>
                            <p class="card-category">Total Expense</p>
                            <h3 class="card-title">20000
                                <small>tk</small>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="">view More...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">info_outline</i>
                            </div>
                            <p class="card-category">Total Profit</p>
                            <h3 class="card-title">20000
                                <small>tk</small>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="">view More...</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-info card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">content_copy</i>
                            </div>
                            <p class="card-category">Total Stock</p>
                            <h3 class="card-title">1000
                                <small>items</small>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <a href="">view More...</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>




            <div class="row">
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-success">
                            <div class="ct-chart" id="dailySalesChart"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-warning">
                            <div class="ct-chart" id="websiteViewsChart"></div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-danger">
                            <div class="ct-chart" id="completedTasksChart"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\9.10.24\resources\views/superadmin/dashboard.blade.php ENDPATH**/ ?>