
<?php $__env->startSection('title'); ?>
    <title>Seminar Details | Non Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>


<?php if(isset($subscriptionfee->userid) == Auth::id()): ?>
    <?php if((isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status =='active'))  and ($subscriptionfee->updated_at) > \Carbon\Carbon::now()->subDays(365)->toDateTimeString()): ?>
        <script>window.location = "<?php echo e(route('Subscriber_seminar_details',$seminar->id)); ?>";</script>
    <?php endif; ?>
<?php endif; ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">

                    <div class="card-header card-header-primary">
                        <h4 class="card-title"> <?php echo e($seminar->title); ?></h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>

                    <div class="card-body">
                        <div class="col-lg-12 col-md-12">
                            <div class="seminar-workshop-box">
                                <h3 class="seminar-title-name"> <?php echo e($seminar->title); ?></h3>


                                <h4 class="seminar-fee"> Fee: <?php echo e($seminar->feegeneral); ?> Tk.</h4>
                                <?php echo $seminar->details; ?>

                                <br>
                                <?php if($seminar->speaker1 !=''): ?>
                                    <h3 class="seminar-title-name"><a href=" <?php echo $seminar->speakerdetails1; ?>" target="_blank"><?php echo $seminar->speaker1; ?></a></h3>
                                    <br>
                                <?php endif; ?>
                                <?php if($seminar->speaker2 !=''): ?>
                                    <h3 class="seminar-title-name"><a href=" <?php echo $seminar->speakerdetails2; ?>" target="_blank"><?php echo $seminar->speaker2; ?></a></h3>
                                    <br>
                                <?php endif; ?>
                                <?php if($seminar->speaker3 !=''): ?>
                                    <h3 class="seminar-title-name"><a href=" <?php echo $seminar->speakerdetails3; ?>" target="_blank"><?php echo $seminar->speaker3; ?></a></h3>
                                    <br>
                                <?php endif; ?>
                                <?php if($seminar->speaker4 !=''): ?>
                                    <h3 class="seminar-title-name"><a href=" <?php echo $seminar->speakerdetails4; ?>" target="_blank"><?php echo $seminar->speaker4; ?></a></h3>
                                    <br>
                                <?php endif; ?>
                                <?php if($seminar->speaker5 !=''): ?>
                                    <h3 class="seminar-title-name"><a href=" <?php echo $seminar->speakerdetails5; ?>" target="_blank"><?php echo $seminar->speaker5; ?></a></h3>
                                    <br>
                                <?php endif; ?>

                                <!--<h3 class="seminar-fee" style="color:blue">Total Seat : <?php echo $seminar->seat; ?></h3>-->


                                <h3 class="seminar-fee" style="color:green">Available Seat : <?php echo $seminar->seat - $seat_count; ?></h3>


                            </div>
                        </div>

                        <div class="form-group col-lg-12 text-center">

                            
                            <form method="POST" action="<?php echo e(route('non-shurjopay-submission')); ?>">
                                <?php echo csrf_field(); ?>
                                <input name="userid" type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control">
                                <input name="seminar_id" type="hidden" value="<?php echo e($seminar->id); ?>" class="form-control">
                                <input name="name" type="hidden" value="<?php echo e(Auth::user()->name); ?>" class="form-control">
                                <input name="email" type="hidden" value="<?php echo e(Auth::user()->email); ?>" class="form-control">
                                <input name="amount" type="hidden" value="<?php echo e($seminar->feegeneral); ?>" class="form-control">
                                <?php if(($seminar->seat - $seat_count)>0): ?>
                                    <button type="submit" class="btn btn-primary"><span>Pay Now</span></button>
                                <?php else: ?>
                                    <h3 class="btn btn-danger"><span>No Seat Available!</span></h3>
                                <?php endif; ?>

                            </form>


                        </div>
                    </div>






                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\august\resources\views/nonsubscriber/Subscribe_seminar_details.blade.php ENDPATH**/ ?>