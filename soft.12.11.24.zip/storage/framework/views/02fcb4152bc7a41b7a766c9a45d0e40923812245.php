Hello <?php echo e($email_data['name']); ?>






Please click the below link to verify your email and activate your account!
<br><br>
<a href="<?php echo e(asset('/')); ?>verify?code=<?php echo e($email_data['verification_code']); ?>">Click Here!</a>

<br><br>
Thank you!
<br>
woforumbd.com<?php /**PATH F:\server\htdocs\WE\26.3.21export\26.3.21\resources\views/mail/signup-email.blade.php ENDPATH**/ ?>