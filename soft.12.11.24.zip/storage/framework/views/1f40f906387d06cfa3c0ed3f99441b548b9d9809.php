
<?php $__env->startSection('title'); ?>
    <title><?php echo e($user->name); ?>'s  Details| Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Edit <?php echo e($user->name); ?>'s Details</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('user-password-change',$user->id)); ?>">
                            
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Name </label>
                                        <span class="bmd-form-group is-filled"><input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>"></span>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> E-mail </label>
                                    <span class="bmd-form-group is-filled"><input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>"></span>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Mobile </label>
                                    <span class="bmd-form-group is-filled"><input type="text" class="form-control" name="mobile" value="<?php echo e($user->mobile); ?>"></span>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> District </label>
                                    <select name="district" class="form-control" required><option selected><?php echo e($user->district); ?><option>Choose...</option> <option>Dhaka</option><option>Faridpur</option><option>Gazipur</option><option>Gopalganj</option><option>Jamalpur</option><option>Kishoreganj</option><option >Madaripur</option><option>Manikganj</option><option>Munshiganj</option><option>Mymensingh</option><option>Narayanganj</option><option>Narsingdi</option><option>Netrokona</option><option>Rajbari</option><option>Shariatpur</option><option>Sherpur</option><option>Tangail</option><option>Bogura</option><option>Joypurhat</option><option>Naogaon</option><option>Natore</option><option>Chapainawabganj</option><option>Pabna</option><option>Rajshahi</option><option>Sirajgonj</option><option>Dinajpur</option><option>Gaibandha</option><option>Kurigram</option><option">Lalmonirhat</option><option>Nilphamari</option><option>Panchagarh</option><option>Rangpur</option><option>Thakurgaon</option><option>Barguna</option><option>Barishal</option><option>Bhola</option><option>Jhalokati</option><option>Patuakhali</option><option>Pirojpur</option><option">Bandarban</option><option>Brahmanbaria</option><option>Chandpur</option><option>Chattogram</option><option>Cumilla</option><option>Cox's Bazar</option><option>Feni</option><option>Khagrachhari</option><option>Lakshmipur</option><option>Noakhali</option><option>Rangamati</option><option>Habiganj</option><option>Moulvibazar</option><option>Sunamganj</option><option>Sylhet</option><option>Bagerhat</option><option>Chuadanga</option><option>Jashore</option><option>Jhenaidah</option><option>Khulna</option><option>Kushtia</option><option>Magura</option><option>Meherpur</option><option>Narail</option><option>Satkhira</option></select>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Facebook Link </label>
                                    <span class="bmd-form-group is-filled"><input type="text" class="form-control" name="facebook" value="<?php echo e($user->facebook); ?>"></span>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Password </label>
                                    <span class="bmd-form-group is-filled"><input class="form-control" name="password" type="password" placeholder="********"></span>
                                </div>

                            </div>
                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>

                        </form>

                    </div>


                </div>




            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tflviici/public_html/resources/views/superadmin/useredit.blade.php ENDPATH**/ ?>