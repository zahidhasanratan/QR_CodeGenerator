<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('asset/assets/img/sidebar-1.jpg')); ?>">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="<?php echo e(route('subscriber-dashboard')); ?>" class="simple-text logo-normal">
            <img src="<?php echo e(asset('asset/images/logo.png')); ?>">
        </a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if(Request::path() =='Subscriber/SubscriberDashboard'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('subscriber-dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>

                </a>
            </li>

            <li class="nav-item <?php if(Request::path() =='Subscriber/PersonalInformation'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('PersonalInformation')); ?>">
                    <i class="material-icons">account_circle</i>
                    <p>Personal Information</p>
                </a>
            </li>


            <li class="nav-item <?php if(Request::path() =='Subscriber/FamilyDetails'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('FamilyDetails')); ?>">
                    <i class="material-icons">face</i>
                    <p>Details of Family </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='Subscriber/IncomeDetails'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('IncomeDetails')); ?>">
                    <i class="material-icons">attach_money</i>
                    <p>Detail of Income</p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='Subscriber/CompanyInformation'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('CompanyInformation')); ?>">
                    <i class="material-icons">apartment</i>
                    <p>Company Information</p>
                </a>
            </li>
            <!--  <li class="nav-item ">
               <a class="nav-link" href="reference.html">
                 <i class="material-icons">bubble_chart</i>
                 <p>Name of Reference</p>
               </a>
             </li> -->

            <li class="nav-item <?php if(Request::path() =='Subscriber/Reference'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('Reference')); ?>">
                    <i class="material-icons">supervisor_account</i>
                    <p>Name of Reference </p>
                </a>
            </li>

            <li class="nav-item <?php if(Request::path() =='Subscriber/Upload'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('Upload')); ?>">
                    <i class="material-icons">upload</i>
                    <p>Upload Photos & Files </p>
                </a>
            </li>



            <li class="nav-item ">
                <a class="nav-link" href="change-request.html">
                    <i class="material-icons">language</i>
                    <p>Change Request </p>
                </a>
            </li>

            <!--  <li class="nav-item ">
               <a class="nav-link" href="#">
                 <i class="material-icons">language</i>
                 <p>Join on Commmittee/Forum</p>
               </a>
             </li> -->

            <li class="nav-item ">
                <a class="nav-link" href="payment.html">
                    <i class="material-icons">language</i>
                    <p>Payment</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="payment-history.html">
                    <i class="material-icons">language</i>
                    <p>Payment History</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="all-services.html#">
                    <i class="material-icons">language</i>
                    <p> All Services</p>
                </a>
            </li>
            <li class="nav-item ">
                <a class="nav-link" href="seminar-workshop.html">
                    <i class="material-icons">language</i>
                    <p> Seminar & Workshop</p>
                </a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="my-activity.html">
                    <i class="material-icons">language</i>
                    <p> My Activity</p>
                </a>
            </li>
            <!--   <li class="nav-item ">
               <a class="nav-link" href="social-links.html">
                 <i class="material-icons">language</i>
                 <p>Social Link</p>
               </a>
             </li> -->

            <li class="nav-item ">
                <a class="nav-link" href="#">
                    <i class="material-icons">language</i>
                    <p>Help Desk</p>
                </a>
            </li>



            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="material-icons">logout</i>
                    <p>logout</p>
                </a>
            </li>


            <!-- <li class="nav-item active-pro ">
              <a class="nav-link" href="./upgrade.html">
                <i class="material-icons">unarchive</i>
                <p>logout</p>
              </a>
            </li> -->
        </ul>
    </div>

</div><?php /**PATH H:\server\htdocs\WE_software\3.01.21\Software\WE\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>