
<?php $__env->startSection('title'); ?>
    <title>Money Receipt | Non Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<?php $__env->startSection('main'); ?>
    <?php if(isset($subscription_fees_submit->userid)): ?>


        <div class="card">
            <div class="card-header card-header-primary">
                <h4 class="card-title">Money Receipt</h4>
                <!-- <p class="card-category">Complete your profile</p> -->
            </div>


            <div class="container">
                <div class="row">
                    <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3" style="font-size: 13px; margin-top: 25px;">
                        <div style="padding:10px 15px;">
                            <div class="row">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <address>
                                        <strong>Women & Ecommerce</strong>
                                        <br>
                                        Haji Shahab Uddin Complex, House: 84, New Airport Road, Banani, Dhaka
                                        <br>
                                        <abbr title="Phone">P:</abbr> 01622236630
                                    </address>
                                </div>
                                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                                    <p>
                                        <em>Date: <?php echo e(Carbon\Carbon::parse($subscription_fees_submit->created_at)->format('Y-m-d')); ?></em>
                                    </p>
                                    <p>
                                        <em>Receipt : #SPF<?php echo e($subscription_fees_submit->id); ?></em>
                                    </p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="text-center">
                                    <h1>Receipt</h1>
                                </div>
                                </span>
                                <table class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>Description</th>
                                        <th></th>
                                        <th class="text-center"></th>
                                        <th class="text-center">Total</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td class="col-md-7"><em> Subscription Fee</em></h4></td>
                                        <td class="col-md-1" style="text-align: center"> </td>
                                        <td class="col-md-1 text-center"></td>
                                        <td class="col-md-3 text-center"><?php echo e($subscription_fees_submit->amount); ?>TK</td>
                                    </tr>

                                    <tr>
                                        <td>   </td>
                                        <td>   </td>
                                        <td class="text-right">
                                            <p>
                                                <strong>Subtotal: </strong>
                                            </p>
                                        </td>
                                        <td class="text-center">
                                            <p>
                                                <strong><?php echo e($subscription_fees_submit->amount); ?>TK</strong>
                                            </p>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>   </td>
                                        <td>   </td>
                                        <td class="text-right"><h4><strong>Total: </strong></h4></td>
                                        <td class="text-center text-danger"><h4><strong><?php echo e($subscription_fees_submit->amount); ?>TK</strong></h4></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <a target="_blank" href="<?php echo e(route('receiptview',$subscription_fees_submit->id)); ?>" class="btn btn-success btn-lg btn-block">
                                    Download/Print   <span class="glyphicon glyphicon-chevron-right"></span>
                                </a></td>
                            </div>
                        </div>
                    </div>
                </div>


            </div>


    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/weforumbd/public_html/resources/views/nonsubscriber/Subscriber_payment_Receipt.blade.php ENDPATH**/ ?>