
<?php $__env->startSection('title'); ?>
    <title>Seminar | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">All Seminar/Workshop/Training</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <?php if(Auth::user()->is_admin !='2'): ?>
                        <a style="float:right" href="<?php echo e(route('admin.seminar.create')); ?>" class="btn btn-primary square-btn-adjust">Add Seminar/Workshop/Training</a>
                       <?php endif; ?>
                        <table id="" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>Event Date</th>
                                <th>Title</th>
                                <th>Type</th>


                                <th>No. Seat</th>
                                <th>Available Seat</th>


                                <th width="45%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $seminar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$seminar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($seminar->eventdate); ?></td>
                                    <td><?php echo e($seminar->title); ?></td>
                                    <td><?php echo e($seminar->type); ?></td>

                                    <td><?php echo e($seminar->seat); ?></td>
                                    <td><?php echo e($seminar->seat - DB::table('seminar_fees')->where('seminar_id', $seminar->id)->count()); ?></td>


                                    <td>
                                        <?php if(Auth::user()->is_admin !='2'): ?>
                                        <a href="<?php echo e(route('certificate.upload',$seminar->id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-upload"></i> Certificate</a>
                                        <a href="<?php echo e(route('seminar.edit',$seminar->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                        <a href="<?php echo e(route('seminar.delete',$seminar->id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('seminar.subscriber.list',$seminar->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View List</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tfoot>
                        </table>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\26.2.22\resources\views/superadmin/seminar/index.blade.php ENDPATH**/ ?>