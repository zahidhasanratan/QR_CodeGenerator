
<?php $__env->startSection('title'); ?>
    <title>Subscriber List | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Subscriber List</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                         <?php $__currentLoopData = $subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($subscriber->entrepreneur_name); ?><br>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\server\htdocs\WE_software\3.01.21\Software\WE\resources\views/superadmin/pendinglist.blade.php ENDPATH**/ ?>