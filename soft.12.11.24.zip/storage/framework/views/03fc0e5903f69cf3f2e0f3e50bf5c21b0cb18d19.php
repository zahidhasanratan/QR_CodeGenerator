
<?php $__env->startSection('title'); ?>
    <title>Pending List | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">

                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Pending List</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <a style="float: right; margin: 0px 0 20px 0" href="<?php echo e(route('pending.userlistexport')); ?>" class="btn btn-xs danger  btn-custom-payment">Export .xlx</a>

                             

                             <table id="" class="table table-striped table-bordered" style="width:100%">

                                 <thead>
                                 <tr>

                                     <th>Joined As Subscriber</th>
                                     <th>Entrepreneur Name</th>
                                     <th>District</th>
                                     <th>Email</th>
                                     <th>Company Name</th>
                                     <th>Action</th>
                                 </tr>
                                 </thead>
                                 <tbody>
                                 <?php $__currentLoopData = $pendinglist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pendinglist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                     <td><?php echo e(Carbon\Carbon::parse($pendinglist->updated_at)->format('d-m-Y')); ?></td>
                                     <td><?php echo e($pendinglist->entrepreneur_name); ?></td>
                                     <td><?php echo e($pendinglist->district); ?></td>
                                     <td><?php echo e($pendinglist->email); ?></td>

                                     <td><?php echo e($pendinglist->company_name); ?></td>
                                     <td><a href="<?php echo e(route('pending.details',$pendinglist->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i> View</a></td>
                                 </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                 </tfoot>
                             </table>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\8.3.22\resources\views/superadmin/pendinglist.blade.php ENDPATH**/ ?>