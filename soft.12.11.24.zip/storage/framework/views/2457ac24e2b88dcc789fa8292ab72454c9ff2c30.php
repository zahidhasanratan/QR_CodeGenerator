
<?php $__env->startSection('title'); ?>
    <title>Subscription Certificate | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title"> <?php echo e(\App\Models\SubscriptionFeess::where(['id' => $subscription_fees_submit->subscriptionid])->pluck('title')->first()); ?></h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <?php

                        $name = $subscription_fees_submit->name;
                        $name_len = $name;
                            $image = "storage/framework/views/certificate/subscriber/{$seminar_id}/{$certificatename->logo}";

                            $createimage = imagecreatefrompng($image);
                        //this is going to be created once the generate button is clicked
              $output = "storage/framework/views/certificate/subscriber/{$seminar_id}/{$subscription_fees_submit->name}.png";

              //then we make use of the imagecolorallocate inbuilt php function which i used to set color to the text we are displaying on the image in RGB format
              $white = imagecolorallocate($createimage, 205, 245, 255);
              $black = imagecolorallocate($createimage, 0, 0, 0);

              //Then we make use of the angle since we will also make use of it when calling the imagettftext function below
              $rotation = 0;

              //we then set the x and y axis to fix the position of our text name
              $origin_x = 280;
              $origin_y=315;

              if($name_len<=7){
                $font_size = 38;
                $origin_y=410;
                $origin_x = 390;
              }
              elseif($name_len<=12){
                $font_size = 34;
                $origin_y=410;
                $origin_x = 360;
              }
              elseif($name_len<=15){
                $origin_y=410;
                $origin_x = 355;
                $font_size = 30;
              }
              elseif($name_len<=20){
                $origin_y=410;
                $origin_x = 348;
                $font_size = 28;
              }
              elseif($name_len<=22){
                $origin_y=410;
                $origin_x = 348;
                $font_size = 26;
              }
              elseif($name_len<=27){
                    $origin_y=410;
                $origin_x = 340;
                $font_size=24;
              }
              elseif($name_len<=33){
                    $origin_y=410;
                $origin_x = 320;
                $font_size=22;
              }
              else {
                $font_size =10;
              }

              $certificate_text = $name;

              //font directory for name
              $drFont = dirname(__FILE__)."/certificate/seminar/developer.ttf";

              //function to display name on certificate picture
              $text1 = imagettftext($createimage, $font_size, $rotation, $origin_x, $origin_y, $black, $drFont, $certificate_text);

              imagepng($createimage,$output,3);



                    ?>
                    <img style="width:100%;height:auto;" src="<?php echo e(asset('/')); ?>storage/framework/views/certificate/subscriber/<?php echo $seminar_id;?>/<?php echo $subscription_fees_submit->name;?>.png">
                    <br>
                    <a target="_blank" href="<?php echo e(asset('/')); ?>storage/framework/views/certificate/subscriber/<?php echo $seminar_id;?>/<?php echo $subscription_fees_submit->name;?>.png" class="btn btn-success">Download My Certificate</a>

                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.3.21\24.3.21\resources\views/subscriber/Subscription_certificate_details.blade.php ENDPATH**/ ?>