
<?php $__env->startSection('title'); ?>
    <title>Company Stock Product | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>



    <div class="content">
        <div class="container-fluid">
            <div class="row">


                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Edit Company Stockkt Product</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <form role="form" method="POST" action="<?php echo e(route('companyproduct.update', $product->id)); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- Use PUT or PATCH for updates -->
                            <fieldset class="col-lg-12 border p-3 mb-3">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">

                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="form-row">
                                    <div class="col-md-4 mb-6">
                                        <label for="productName">Product Name</label>
                                        <span class="required-star"></span>
                                        <input type="text" name="name" class="form-control" required placeholder="Enter Product Name" value="<?php echo e($product->name); ?>">
                                    </div>

                                    <div class="col-md-4 mb-6">
                                        <label for="category">Category</label>
                                        <select name="category" class="form-control" required>
                                            <option value="">Select Category</option>
                                            <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id == $product->categoryId ? 'selected' : ''); ?>>
                                                    <?php echo e($category->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-6">
                                        <label for="price">Price</label>
                                        <span class="required-star"></span>
                                        <input name="price" type="text" class="form-control" required placeholder="Price" value="<?php echo e($product->price); ?>">
                                    </div>

                                    <div class="col-md-4 mb-6">
                                        <label for="unit">Unit Type</label>
                                        <select class="form-control" name="unit" required>
                                            <option value="">Select a Unit Type</option>
                                            <?php $__currentLoopData = \App\Models\Unit::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($unit->name); ?>" <?php echo e($unit->name == $product->unit ? 'selected' : ''); ?>>
                                                    <?php echo e($unit->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-4 mb-6">
                                        <label for="photo">Product Photo</label>
                                        <div class="custom-file">
                                            <input name="photo" type="file" accept=".jpg, .png" class="custom-file-input">
                                            <label class="custom-file-label">Choose jpg, jpeg, png file</label>
                                        </div>
                                        <small>Resize your photo (width: 180px X height: 250px)</small>

                                    </div>
                                    <div class="col-md-4 mb-6">
                                        <?php if($product->photo): ?>
                                            <img style="height: 80px; width: 100px;" src="<?php echo e(asset('uploads/companyproducts/' . $product->photo)); ?>">
                                        <?php endif; ?>
                                    </div>

                                </div>

                                <?php $__currentLoopData = \App\Models\Purchasecompany::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $stockIn = \App\Models\Companystock::where('productId', $product->id)
                                                                      ->where('warehouseId', $warehouse->id)
                                                                      ->first();
                                    ?>
                                    <div class="form-row">
                                        <div class="col-md-4 mb-6">
                                            <label for="warehouse">Warehouse</label>
                                            <select class="form-control" name="warehouseId[]">
                                                <option value="<?php echo e($warehouse->id); ?>" <?php echo e($stockIn ? 'selected' : ''); ?>>
                                                    <?php echo e($warehouse->name); ?>

                                                </option>
                                            </select>
                                        </div>

                                        <div class="col-md-4 mb-6">
                                            <label for="quantity">Stock</label>
                                            <span class="required-star"></span>
                                            <input type="text" name="quantity[]" class="form-control" required placeholder="Enter Stock Quantity"
                                                   value="<?php echo e($stockIn ? $stockIn->quantity : ''); ?>">
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </fieldset>

                            <div class="form-group col-lg-12 text-center">
                                <button type="submit" class="btn btn-primary"><span>Submit</span></button>
                            </div>
                        </form>


                    </div>
                </div>
            </div>







        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\9.10.24\resources\views/superadmin/companyproduct/edit.blade.php ENDPATH**/ ?>