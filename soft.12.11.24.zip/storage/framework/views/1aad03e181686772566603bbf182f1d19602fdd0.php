<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\server\htdocs\WE\28.1.21\Software\WE\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>