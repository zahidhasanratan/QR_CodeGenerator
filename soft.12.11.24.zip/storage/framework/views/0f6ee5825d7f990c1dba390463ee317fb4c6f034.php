
<?php $__env->startSection('title'); ?>
    <title>Seminar | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Edit Seminar</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">


                        <form role="form" method="post" action="<?php echo e(route('seminar.update',$seminar->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                                <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "></small></legend>

                                <div class="form-row">

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Add Seminar / Workshop / Training Name </label>
                                        <span class="requierd-star"></span>
                                        <input type="text" name="title" class="form-control" required value="<?php echo e($seminar->title); ?>">
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Number of Seat</label>
                                        <input type="text" name="seat" class="form-control" value="<?php echo e($seminar->seat); ?>" required>
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Fee Member</label>
                                        <input type="text" name="fee" class="form-control" value="<?php echo e($seminar->fee); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Fee General</label>
                                        <input type="text" name="feegeneral" class="form-control" value="<?php echo e($seminar->feegeneral); ?>">
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Event Date </label>
                                        <input type="text" class="form-control" name="eventdate" value="<?php echo e($seminar->eventdate); ?>">
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Event Time </label>
                                        <input type="text" name="eventtime" class="form-control" value="<?php echo e($seminar->eventtime); ?>">
                                    </div>

                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013">Venue &amp; Contact Details </label>

                                        <textarea class="form-control" rows="5" name="details" id="comment"><?php echo e($seminar->details); ?></textarea>

                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 1 </label>
                                        <input type="text" name="speaker1" class="form-control" value="<?php echo e($seminar->speaker1); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 1 Details </label>
                                        <input type="text" name="speakerdetails1" class="form-control" value="<?php echo e($seminar->speakerdetails1); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 2 </label>
                                        <input type="text" name="speaker2" class="form-control" value="<?php echo e($seminar->speaker2); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 2 Details </label>
                                        <input type="text" name="speakerdetails2" class="form-control" value="<?php echo e($seminar->speakerdetails2); ?>">
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 3 </label>
                                        <input type="text" name="speaker3" class="form-control" value="<?php echo e($seminar->speaker3); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 3 Details </label>
                                        <input type="text" name="speakerdetails3" class="form-control" value="<?php echo e($seminar->speakerdetails3); ?>">
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 4 </label>
                                        <input type="text" name="speaker4" class="form-control" value="<?php echo e($seminar->speaker4); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 4 Details </label>
                                        <input type="text" name="speakerdetails4" class="form-control" value="<?php echo e($seminar->speakerdetails4); ?>">
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 5 </label>
                                        <input type="text" name="speaker5" class="form-control" value="<?php echo e($seminar->speaker5); ?>">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013">Speaker 5 Details </label>
                                        <input type="text" name="speakerdetails5" class="form-control" value="<?php echo e($seminar->speakerdetails5); ?>">
                                    </div>
                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013">Type </label>
                                        <select name="type" class="form-control" required>
                                            <option><?php echo e($seminar->type); ?></option>
                                            <option>Seminar</option>
                                            <option>Workshop</option>
                                            <option>Training</option>
                                            <option>Select Type</option>
                                        </select>
                                    </div>
                                </div>
                            </fieldset>
                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Save</span></button></div>
                        </form>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\15.2.21\Software\WE\resources\views/superadmin/seminar/edit.blade.php ENDPATH**/ ?>