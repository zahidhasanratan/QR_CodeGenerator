<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('asset/assets/img/sidebar-1.jpg')); ?>">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="<?php echo e(route('subscriber-dashboard')); ?>" class="simple-text logo-normal">
            <img src="<?php echo e(asset('asset/images/logo.png')); ?>">
        </a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if(Request::path() =='admin/report'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.report')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Report</p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='admin/home'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='admin/nonsubscriberlist'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('nonsub.userlist')); ?>">
                    <i class="material-icons">person</i>
                    <p>Non Subscriber</p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='admin/subscriber/paidsubscriberlist'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.paidsubscriberlist')); ?>">
                    <i class="material-icons">people</i>
                    <p>Subscriber List</p>
                </a>
            </li>

            <!--  <li class="nav-item ">
               <a class="nav-link" href="personal-information.html">
                 <i class="material-icons">language</i>
                 <p>Personal Information</p>
               </a>
             </li> -->
            <li class="nav-item <?php if(Request::path() =='admin/userlist'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.userlist')); ?>">
                    <i class="material-icons">face</i>
                    <p>All User (NonSub+Sub) </p>
                </a>
            </li>
            <li class="nav-item ">

                
                
                


                
                    
                    
                
                <ul class="submenu-super">
                    
                            
                        
                    
                        
                        
                    
                            
                            
                        
                    


                    
                            
                        
                    
                    
                    
                    
                    

                    
                            
                        
                    

                </ul>
            </li>

            <li class="nav-item <?php if(Request::path() =='admin/subscriber/pendinglist'): ?>
                    active
                    <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.pendinglist')); ?>">
                    <i class="material-icons">timer</i>
                    <p>Pending Subscriber </p>
                </a>
            </li>
            <li class="nav-item <?php if(Request::path() =='admin/subscriber/rejectedlist'): ?>
                    active
                    <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.rejectedlist')); ?>">
                    <i class="material-icons">clear</i>
                    <p>Rejected List </p>
                </a>
            </li>

            <li class="nav-item <?php if(Request::path() =='admin/subscriber/notice'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.notice')); ?>">
                    <i class="material-icons">note</i>
                    <p>Notice </p>
                </a>
            </li>




            
                
                    
                    
                

                
                    
                    
                    
                    
                    

                    

                
            
            <li class="nav-item <?php if(Request::path() =='admin/subscriber/subscription'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.subscription.fee')); ?>">
                    <i class="material-icons">receipt</i>
                    <p>Subscription Fee </p>
                </a>
            </li>

            <li class="nav-item <?php if(Request::path() =='admin/subscriber/seminar'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.seminar')); ?>">
                    <i class="material-icons">work</i>
                    <p>Training/ Seminar/ Workshop </p>
                </a>
            </li>

            
                
                    
                    
                
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                

            




            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="material-icons">language</i>
                    <p>logout</p>
                </a>
            </li>


            <!-- <li class="nav-item active-pro ">
              <a class="nav-link" href="./upgrade.html">
                <i class="material-icons">unarchive</i>
                <p>logout</p>
              </a>
            </li> -->
        </ul>
    </div>

</div><?php /**PATH F:\server\htdocs\WE\26.3.21export\24.3.21\resources\views/layouts/partial/super/sidebar.blade.php ENDPATH**/ ?>