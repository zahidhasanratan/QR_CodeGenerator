
<?php $__env->startSection('title'); ?>
    <title>Subscriber Signup | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('signup'); ?>

    <div id="LoginForm">
        <div class="container">
            <!-- <h1 class="form-heading">login Form</h1> -->
            <div class="login-form">
                <div class="main-div2">
                    <div class="panel panel-custom">
                        <div class="fadeIn first">
                            <img src="<?php echo e(asset('asset/images/logo.png')); ?>" id="icon" alt="We Logo">
                            <!-- <h1>Aditya News</h1> -->
                        </div>
                        <h2>Want to be a Subscriber of Women & e-Commerce Subscriber Registration</h2>
                        <div class="flash-message">
                            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Session::has('alert-' . $msg)): ?>
                                    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="col-md-12 mb-12">
                                <label style="text-align: left;" for="validationServer013">Company Name </label>

                                <input type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="ie: Women & e-Commerce" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Email  </label>

                                <input type="text" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="ie: subscriber@gmail.com" value="<?php echo e(old('email')); ?>"  required autocomplete="email" required autocomplete="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Mobile  </label>

                                <input type="text" name="mobile" class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mobile')); ?>" placeholder="ie: 017*****" required autocomplete="mobile">

                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>


                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Password  </label>
                                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required autocomplete="new-password" required autocomplete="new-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Confirmed Password  </label>

                                <input type="password" name="password_confirmation" required autocomplete="new-password" class="form-control is-valid" placeholder="Confirmed Password" required autocomplete="new-password">
                            </div>

                            <div class="col-sm-12 form-group"><div class="row"><div class="custom-control custom-checkbox"><div class="col-form-label-sm font-weight-bold mb-0 custom-control custom-checkbox"><input type="checkbox" autocomplete="off" class="custom-control-input" value="true" id="__BVID__16" required><label class="custom-control-label" for="__BVID__16">
                                                You must agree with above
                                                <a target="__blank" href="#">Terms &amp; Conditions</a></label></div> <div class="invalid-feedback"></div></div></div></div>


                            <div class="col-sm-3 form-group mb-0"><button type="submit" class="btn btn-primary text-white">Submit</button></div>
                            <div class="col-sm-9 form-group"><p class="text-right">
                                    If you are already registered ?
                                    <a href="<?php echo e(route('signin')); ?>" class="btn btn-danger font-weight-bold rounded-50 ml-2">Login</a></p></div>


                        </div>
                    </form>

                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Member.Member_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\8.2.21\Software\WE\resources\views/Member/signup.blade.php ENDPATH**/ ?>