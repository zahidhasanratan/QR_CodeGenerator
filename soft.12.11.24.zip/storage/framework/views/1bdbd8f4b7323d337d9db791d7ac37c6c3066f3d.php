
<?php $__env->startSection('title'); ?>
    <title>Subscription | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Upload Certificate</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">


                        <form role="form" method="post" action="<?php echo e(route('subscriptioncertificate.update',$seminar->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                                <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "></small></legend>

                                <div class="form-row">

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Title </label>
                                        <span class="requierd-star"></span>
                                        <input type="text" name="title" class="form-control" required value="<?php echo e($seminar->title); ?>">
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Upload Certificate</label>
                                        <input type="file" name="logo" class="form-control" value="<?php echo e($seminar->logo); ?>" required>
                                    </div>


                                    <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Uploaded Certificate</label>
                                    <img style="width:300px;height:auto;" src="<?php echo e(asset('')); ?>storage/framework/views/certificate/subscriber/<?php echo e($seminar->id); ?>/<?php echo e($seminar->logo); ?>">
                                    </div>

                                </div>
                            </fieldset>
                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Save</span></button></div>
                        </form>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\8.3.22\resources\views/superadmin/subscription/certificateupload.blade.php ENDPATH**/ ?>