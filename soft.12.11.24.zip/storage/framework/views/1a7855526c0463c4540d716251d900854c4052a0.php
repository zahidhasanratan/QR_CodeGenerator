
<?php $__env->startSection('title'); ?>
    <title>Subscriber OTP Varification | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('signup'); ?>

    <div id="LoginForm">
        <div class="container">
            <!-- <h1 class="form-heading">login Form</h1> -->
            <div class="login-form">
                <div class="main-div">
                    <div class="panel">
                        <div class="fadeIn first">
                            <img src="<?php echo e(asset('asset/images/logo.png')); ?>" id="icon" alt="We Logo">
                            <!-- <h1>Aditya News</h1> -->
                        </div>
                        <h2>Account Varification</h2>
                        <p>varify your OTP from mobile</p>
                        <div class="flash-message">
                            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Session::has('alert-' . $msg)): ?>
                                    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <p class="alert alert">Varify your OTP</p>
                    <form id="Login" method="POST" action="<?php echo e(route('verify.otpreset')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group bmd-form-group is-filled">
                            <input type="text" name="otp" class="form-control " id="inputEmail" placeholder="Enter Your OTP" value="" required="" autocomplete="email" autofocus="">

                        </div>



                        <button type="submit" class="btn btn-primary">Varify OTP</button>
                    </form>
                    <div class="footer-custom">
                        <p><a target="__blank" href="https://esoft.com.bd/">Software Developed by</a> e-Soft</p>
                    </div>
                </div>

            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Member.Member_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\1.4.21\1.4..21\resources\views/Member/otpreset.blade.php ENDPATH**/ ?>