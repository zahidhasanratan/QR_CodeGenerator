<?php if(isset($subscriptionfee->userid) == Auth::id()): ?>
    <?php if((isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status =='active'))  and ($subscriptionfee->updated_at) < \Carbon\Carbon::now()->subDays(365)->toDateTimeString()): ?>
        <script>window.location = "<?php echo e(route('non-subscriber-dashboard')); ?>";</script>
    <?php endif; ?>
<?php endif; ?>

<?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\September\5.9.22\resources\views/subscriber/redirection.blade.php ENDPATH**/ ?>