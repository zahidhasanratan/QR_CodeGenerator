<!-- Sidebar -->
<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('/')); ?>asset/assets/img/sidebar-1.jpg">
    
    
    
    
    

    <div class="sidebar-wrapper">
        <div class="page-wrapper chiller-theme toggled">

            <nav id="sidebar" class="sidebar-wrapper">
                <div class="logo">
                    <a href="<?php echo e(route('subadmin.home')); ?>" class="simple-text logo-normal">
                        <img src="<?php echo e(asset('/')); ?>asset/images/logo.png">
                    </a>
                </div>
                <div class="sidebar-content">

                    <div class="sidebar-menu">
                        <ul>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>SR Client</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>

                                        <li>
                                            <a href="<?php echo e(route('shop.index')); ?>">View SR Shop</a>
                                        </li>

                                    </ul>
                                </div>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Warehouse</span>
                                </a>
                                <div class="sidebar-submenu">
                                    <ul>
                                        <?php
                                            $warehouses = \App\Models\Warehouse::where('id', auth()->user()->warehouse)->get();
                                        ?>

                                        <?php if($warehouses->isEmpty()): ?>
                                            <li>
                                                <a href="#"> No Warehouse is Assigned</a>
                                               </li>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(route('warehouse.sr.show', $warehouse->id)); ?>"><?php echo e($warehouse->name); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>


                                    </ul>
                                </div>
                            </li>

                            <li class="sidebar-dropdown">
                                <a href="#">
                                    <i class="far fa-gem"></i>
                                    <span>Order</span>
                                </a>
                                <div class="sidebar-submenu" style="display: none;">
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('sr.category')); ?>">New Order</a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('sr.all_order')); ?>">All Order</a>
                                        </li>


                                    </ul>
                                </div>
                            </li>

                        </ul>
                    </div>
                    <!-- sidebar-menu  -->
                </div>

            </nav>
        </div>
    </div>
</div>
<!-- Side Bar -->

<?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\27.10.24\resources\views/layouts/partial/sub/sidebar.blade.php ENDPATH**/ ?>