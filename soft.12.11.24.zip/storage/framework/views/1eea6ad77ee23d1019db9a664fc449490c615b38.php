
<?php $__env->startSection('title'); ?>
    <title>Dashboard | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <?php if(isset($subscriptionfee->userid) == Auth::id()): ?>
        <?php if(isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status =='active')): ?>
            <?php if(isset($subscriber->step1)): ?>
                <?php if($subscriber->step1 != ''): ?>
                    <script>window.location = "<?php echo e(route('second_step')); ?>";</script>
                    <?php exit; ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>

        <?php endif; ?>
    <?php endif; ?>
    <?php if(isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status !='active')): ?>
        <div class="card-header card-header-primary" style="color:red">
            <h3>We are Reviewing Your Profile...</h3>
            <p>We will inform you soon.</p>
        </div>
    <?php endif; ?>



    <div class="container-fluid">


        <div class="row">
            <div class="col-md-12">
                <div class="card card-chart">
                    <div class="card-header card-header-danger">

                    </div>
                    <div class="card-body">
                        <h4 class="card-title">Notice</h4>
                        <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="text-align: justify; padding-bottom: 10px" class="card-category"><?php echo e($loop->iteration); ?>, <?php echo e($notice->short); ?></p>
                            <a href="<?php echo e(route('nonnotice.details',$notice->slug)); ?>">View Details</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>

                </div>
            </div>

        </div>






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/weforumbd/public_html/resources/views/nonsubscriber/notice/all.blade.php ENDPATH**/ ?>