
<?php $__env->startSection('title'); ?>
    <title>All Order List | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>



    <div class="content">
        <div class="container-fluid">
            <div class="row">


                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">All Order List</h4>
                    </div>

                    <!-- data table -->

                    <div class="table-wrapper">
                        <div class="card-body">



                            <div class="add-button text-right">
                                <a href="<?php echo e(route('sr.category')); ?>" class="btn btn-primary text-capitalize"><span>New Order</span></a>
                            </div>

                            <div class="table-responsive">

                                <table id="warehouseTable" class="table table-hover" cellspacing="0" width="100%">
                                    <thead class="text-primary">
                                    <tr>
                                        <th>Serial </th>
                                        <th>Order Number </th>
                                        <th> Date </th>
                                        <th> Shop Name </th>
                                        <th> Total Amount </th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($key); ?> </td>
                                            <td> #<?php echo e($list->id); ?> </td>
                                            <td> <?php echo e($list->created_at->format('F d, Y')); ?> </td>
                                            <td> <?php echo e(\App\Models\SrShop::where('id', $list->shop_id)->first()->shopName); ?> </td>
                                            <td> <?php echo e($list->final_total); ?> </td>
                                            <td class="td-actions text-right">


                                                <button type="button" onclick="window.location='<?php echo e(route('order.success', $list->id)); ?>'" rel="tooltip" class="btn btn-primary btn-link btn-sm" title="View Order Details">
                                                    <i class="fas fa-eye"></i>
                                                </button>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- DataTable Initialization Script -->
                    
                    
                    
                    
                    
                    <script>
                        $(document).ready(function() {
                            $('#warehouseTable').DataTable({
                                "order": [[ 1, "desc" ]] // Change '1' to the appropriate column index for sorting
                            });
                        });
                    </script>

                </div>
            </div>







        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/anotheruser/software.nurjahan.com.bd/resources/views/subadmin/order/all_order_shop.blade.php ENDPATH**/ ?>