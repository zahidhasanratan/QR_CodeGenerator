
<?php $__env->startSection('title'); ?>
    <title>Family Details | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Details of Family</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>

                    <form method="POST" action="<?php echo e(route('familydetails-form')); ?>">
                        
                        <?php echo csrf_field(); ?>
                        <input name="subscriber_id" type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control">


                        <div class="card-body">
                            <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                                <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Details of Family </small></legend>

                                <div class="form-row">

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Name Of Spouse/Guardian </label>
                                        <span class="requierd-star"></span>
                                        <input name="spouse_guardian" type="text" class="form-control" value="<?php echo e($subscriber->spouse_guardian); ?>"
                                               required>
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Contact Number of Spouse/Guardian</label>
                                        <span class="requierd-star"></span>
                                        <input name="spouse_guardian_contact" type="text" class="form-control" value="<?php echo e($subscriber->spouse_guardian_contact); ?>"
                                               required>
                                        <?php $__errorArgs = ['spouse_guardian_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> Occupation of Spouse/Guardian </label>
                                        <span class="requierd-star"></span>
                                        <input name="occupation_spouse_guardian" type="text" class="form-control" value="<?php echo e($subscriber->occupation_spouse_guardian); ?>"
                                               required>
                                    </div>


                                    <div class="col-md-6 mb-6">
                                        <label for="validationServer013"> How Many Children do you have?</label>
                                        <span class="requierd-star"></span>

                                        <select id="inputState" name="children" class="form-control">
                                            <option selected><?php echo e($subscriber->children); ?></option>
                                            <option>No</option>
                                            <option>One</option>
                                            <option>Two</option>
                                            <option>Three</option>
                                            <option>Four</option>
                                        </select>
                                    </div>

                                </div>
                            </fieldset>
                            <div class="form-group col-lg-12 text-center"><button name="" type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                        </div>

                    </form>



                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.3.21\24.3.21\resources\views/subscriber/FamilyDetails.blade.php ENDPATH**/ ?>