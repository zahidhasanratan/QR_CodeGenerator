
<?php $__env->startSection('title'); ?>
    <title>Reports  | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="card">
                <div class="card-header card-header-primary">
                    <h4 class="card-title">Add Admin </h4>
                    <!-- <p class="card-category">Complete your profile</p> -->
                </div>


                <div class="card-body">
                    <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                        <legend class="w-25 text-center main-title"></legend>

                        <div class="form-row">

                            <div class="col-md-6 mb-6">
                                <label for="validationServer013"> Name  </label>

                                <input type="text" class="form-control" required="">
                            </div>


                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Role Name</label>

                                <input type="text" class="form-control" required="">
                            </div>




                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Edit</label>



                                <label class="container">Superadmin
                                    <input type="checkbox" checked="checked">
                                    <span class="checkmark"></span>
                                </label>


                                <label class="container">Moderator
                                    <input type="checkbox" checked="checked">
                                    <span class="checkmark"></span>
                                </label>


                                <label class="container">Admin
                                    <input type="checkbox" checked="checked">
                                    <span class="checkmark"></span>
                                </label>

                                <!-- <div class="custom-control">
                                    <label class="con">One
                                        <input type="checkbox" checked="checked">
                                        <span class="checkmark"></span>
                                      </label>
                                </div>

                                <div class="custom-control">
                                    <label class="con">One
                                        <input type="checkbox" checked="checked">
                                        <span class="checkmark"></span>
                                      </label>
                                </div> -->

                            </div>

                        </div>
                    </fieldset>
                    <div class="form-group col-lg-12 text-center"><button name="" type="submit" class="btn btn-primary"><span>SAve</span></button></div>
                </div>

                <style>

                    .checkmark{
                        display: none;
                    }
                    /* Create a custom checkbox */
                    /*.checkmark {
                      position: absolute;
                      top: 0;
                      left: 0;
                      height: 20px;
                      width: 20px;
                      background-color: #eee;
                      border-radius: 0px !important;
                    }*/

                    /* On mouse-over, add a grey background color */


                    /* When the checkbox is checked, add a blue background */

                    /* Create the checkmark/indicator (hidden when not checked) */


                    /* Show the checkmark when checked */

                </style>
                </style>
                </div>
                </div>
                  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\server\htdocs\WE\26.3.21export\26.3.21\resources\views/superadmin/adminadd.blade.php ENDPATH**/ ?>