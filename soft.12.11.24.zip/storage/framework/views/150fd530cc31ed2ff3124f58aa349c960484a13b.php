
<?php $__env->startSection('title'); ?>
    <title>User List | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">User List</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <a style="float: right; margin: 0px 0 20px 0" href="<?php echo e(route('nonsub.userlistexport')); ?>" class="btn btn-xs danger  btn-custom-payment">Export .xlx</a>
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>User Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>District</th>
                                <th>facebook</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $userlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$userlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($userlist->name); ?></td>
                                    <td><?php echo e($userlist->email); ?></td>
                                    <td><?php echo e($userlist->mobile); ?></td>
                                    <td><?php echo e($userlist->district); ?></td>
                                    <td><?php echo e($userlist->facebook); ?></td>
                                    <td><a href="<?php echo e(route('user.edit',$userlist->id)); ?>" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> Edit</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                        </table>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\server\htdocs\WE\26.3.21export\26.3.21\resources\views/superadmin/userlist.blade.php ENDPATH**/ ?>