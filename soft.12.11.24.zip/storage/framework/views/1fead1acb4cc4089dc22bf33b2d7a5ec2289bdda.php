<p>Hi, <?php echo e($email_data['name']); ?></p>
<br>
<p>Your User Id : <?php echo e($email_data['email']); ?></p>
<p>Your User Password : <?php echo e($email_data['password']); ?></p>
<p><a href="<?php echo e(asset('signin')); ?>">Login</a></p>

<br><br>
Thank you!
<br>
weforumbd.org<?php /**PATH /home/weforumbd/public_html/resources/views/mail/passwordEmail.blade.php ENDPATH**/ ?>