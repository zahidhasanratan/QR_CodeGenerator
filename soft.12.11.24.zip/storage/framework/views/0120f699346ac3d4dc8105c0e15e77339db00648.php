Hello <?php echo e($email_data['name']); ?>

<br><br>
Your First Step for subscriber enlistment process has successfully been completed.
<br>
You will get confirmation email with in a very short time.





<br><br>
Thank you!
<br>
woforumbd.com<?php /**PATH H:\xamp.7.4\htdocs\WE\20.3.21\resources\views/mail/signup-email.blade.php ENDPATH**/ ?>