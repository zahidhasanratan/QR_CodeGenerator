
<?php $__env->startSection('title'); ?>
    <title>Shop Add | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>



    <div class="content">
        <div class="container-fluid">
            <div class="row">


                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">Add Shop</h4>
                    </div>

                    <div class="card-body">
                        <form role="form" method="POST" action="<?php echo e(route('shop.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <fieldset class="col-lg-12 border p-3 mb-3">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">

                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="form-row">

                                    <div class="col-md-6 mb-6">
                                        <label for="productName">Shop Name</label>
                                        <span class="required-star"></span>
                                        <input type="text" name="name" class="form-control" required placeholder="Enter Shop Name">
                                    </div>



                                    <div class="col-md-6 mb-6">
                                        <label for="price">Owner Name</label>
                                        <span class="required-star"></span>
                                        <input name="ownerName" type="text" class="form-control" required placeholder="Owner Name">
                                    </div>

                                    <div class="col-md-6 mb-6">
                                        <label for="price">Mobile</label>
                                        <span class="required-star"></span>
                                        <input name="Mobile" type="text" class="form-control" required placeholder="Mobile">
                                    </div>
                                    <div class="col-md-6 mb-6">
                                        <label for="price">Address</label>
                                        <span class="required-star"></span>
                                        <input name="Address" type="text" class="form-control" required placeholder="Address">
                                    </div>

                                    <input name="srId" type="hidden" class="form-control" required placeholder="Address" value="<?php echo e($userId); ?>">
                                    <input name="warehouseId" type="hidden" class="form-control" required placeholder="Address" value="<?php echo e($warehouseId); ?>">



                                </div>



                            </fieldset>

                            <div class="form-group col-lg-12 text-center">
                                <button type="submit" class="btn btn-primary"><span>Submit</span></button>
                            </div>
                        </form>


                    </div>


                </div>
            </div>







        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\14.10.24\resources\views/Subadmin/shop/create.blade.php ENDPATH**/ ?>