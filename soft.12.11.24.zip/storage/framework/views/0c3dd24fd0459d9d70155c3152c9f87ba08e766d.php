<?php echo e($slot); ?>

<?php /**PATH F:\server\htdocs\WE\28.1.21\Software\WE\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>