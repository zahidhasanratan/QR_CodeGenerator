
<?php $__env->startSection('title'); ?>
    <title>Non Subscriber List | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Non Subscriber List</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>

                    <div class="card-body">
                        <a style="float: right; margin: 0px 0 20px 0" href="<?php echo e(route('sub.userlistexport')); ?>" class="btn btn-xs danger  btn-custom-payment">Export .xlx</a>
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Mobile</th>
                                <th>District</th>
                                
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $nonsubscriberlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$nonsubscriberlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($nonsubscriberlist->name); ?></td>
                                    <td><?php echo e($nonsubscriberlist->email); ?></td>
                                    <td><?php echo e($nonsubscriberlist->mobile); ?></td>
                                    <td><?php echo e($nonsubscriberlist->district); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tfoot>
                        </table>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\29.3.21\28.3.21\resources\views/subadmin/nonsubscriberuserlist.blade.php ENDPATH**/ ?>