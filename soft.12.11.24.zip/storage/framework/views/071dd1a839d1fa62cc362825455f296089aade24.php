
<?php $__env->startSection('title'); ?>
    <title>Admin Edit  | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <div class="container-fluid">
        <div class="row">
            <div class="card">
                <div class="card-header card-header-primary">
                    <h4 class="card-title">Add Admin </h4>
                    <!-- <p class="card-category">Complete your profile</p> -->
                </div>


                <div class="card-body">
                    <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                        <legend class="w-25 text-center main-title"></legend>
                        <form method="POST" action="<?php echo e(route('admin-password-change',$admin->id)); ?>">
                            <?php echo csrf_field(); ?>
                        <div class="form-row">

                            <div class="col-md-6 mb-6">
                                <label for="validationServer013"> Name  </label>

                                <input type="text" name="name" class="form-control" value="<?php echo e($admin->name); ?>" required>
                            </div>


                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Email</label>

                                <input type="text" name="email" class="form-control"  value="<?php echo e($admin->email); ?>" required>
                            </div>




                            <div class="col-md-6 mb-6">

                                <label class="container">Sub Admin
                                    <input name="role" type="radio" value="2" <?php if($admin->is_admin =='2'): ?> checked <?php endif; ?>>
                                    <span class="checkmark"></span>
                                </label>

                            </div>
                            <div class="col-md-6 mb-6">
                                <label for="validationServer013">Password</label>

                                <input type="text" name="password" class="form-control" placeholder="******">
                            </div>
                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                        </div>
                        </form>
                    </fieldset>

                </div>

                <style>

                    .checkmark{
                        display: none;
                    }
                    /* Create a custom checkbox */
                    /*.checkmark {
                      position: absolute;
                      top: 0;
                      left: 0;
                      height: 20px;
                      width: 20px;
                      background-color: #eee;
                      border-radius: 0px !important;
                    }*/

                    /* On mouse-over, add a grey background color */


                    /* When the checkbox is checked, add a blue background */

                    /* Create the checkmark/indicator (hidden when not checked) */


                    /* Show the checkmark when checked */

                </style>
                </style>
                </div>
                </div>
                  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\29.3.21\28.3.21\resources\views/superadmin/adminedit.blade.php ENDPATH**/ ?>