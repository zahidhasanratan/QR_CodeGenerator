
<?php $__env->startSection('title'); ?>
    <title>Notice | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Create Notice</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">

                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Create Notice </small></legend>

                            <div class="form-row">
                                <form role="form" method="post" action="<?php echo e(route('notice.store')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                <div class="col-md-12 mb-12">
                                    <label for="validationServer013"> Title </label>
                                    <span class="requierd-star"></span>
                                    <input class="form-control" name="title" placeholder="Title" />
                                </div>

                                <div class="col-md-12 mb-12">
                                    <label for="validationServer013"> Date</label>
                                    <span class="requierd-star"></span>
                                    <input class="form-control" name="publishdate" placeholder="Publish Date" />

                                </div>
                                <div class="col-md-12 mb-12">
                                    <label for="validationServer013">Short</label>
                                    <span class="requierd-star"></span>
                                    <textarea class="form-control" rows="3" name="short"></textarea>
                                </div>
                                <div class="col-md-12 mb-12">
                                    <label for="validationServer013">Description</label>
                                    <span class="requierd-star"></span>
                                    <textarea class="form-control ckeditor" rows="3" name="description"></textarea>
                                </div>
                                    <div class="form-group col-lg-12 text-center"><button name="" type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                                </form>

                            </div>
                        </fieldset>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/weforumbd/public_html/resources/views/superadmin/notice/create.blade.php ENDPATH**/ ?>