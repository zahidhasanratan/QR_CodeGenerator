<?php if(isset($subscriptionfee->userid) == Auth::id()): ?>
    <?php if(isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status =='active')  and ($subscriptionfee->updated_at) > \Carbon\Carbon::now()->subDays(365)->toDateTimeString()): ?>
        <?php if(isset($subscriber->step1)): ?>
            <?php if($subscriber->step1 != ''): ?>
                <script>window.location = "<?php echo e(route('second_step')); ?>";</script>
                <?php exit; ?>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>

    <?php endif; ?>
<?php endif; ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\7.3.22\resources\views/nonsubscriber/redirection.blade.php ENDPATH**/ ?>