
<?php $__env->startSection('title'); ?>
    <title>Personal Information | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

    <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Personal Information</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>

                    <form method="POST" action="<?php echo e(route('personal-form')); ?>">
                        
                        <?php echo csrf_field(); ?>
                        <input name="subscriber_id" type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control">

                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <!-- <legend class="w-50 text-center main-title"><small class="text-uppercase font-weight-bold ">Personal Information</small></legend>  -->

                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Entrepreneur’s Name </label>
                                    <span class="requierd-star"></span>
                                    <input name="entrepreneur_name" type="text" class="form-control" placeholder="Entrepreneur’s Name" value="<?php echo e($subscriber->entrepreneur_name); ?>" required autocomplete="entrepreneur_name" autofocus>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Father’s Name </label>
                                    <span class="requierd-star"></span>
                                    <input name="fname" type="text" class="form-control"
                                           value="<?php echo e($subscriber->fname); ?>" required autocomplete="fname" autofocus>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Mother's Name </label>
                                    <span class="requierd-star"></span>
                                    <input name="mname" type="text" class="form-control"
                                           value="<?php echo e($subscriber->mname); ?>" required autocomplete="mname" autofocus>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label class="control-label">Date Of Birth</label>
                                    <div class="input-group date">
                                        <input name="dob" class="form-control" type="text" value="<?php echo e($subscriber->dob); ?>" required autocomplete="dob" autofocus/>
                                        <span class="input-group-append">
                                                                        <button class="btn btn-outline-secondary" type="button">
                                                                            <i class="fa fa-calendar"></i>
                                                                        </button></span>
                                    </div>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Gender </label>
                                    <span class="requierd-star"></span>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" value="Male" class="custom-control-input" id="defaultGroupExample1" name="gender" <?php if(($subscriber->gender)=='Male'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="defaultGroupExample1">Male</label>
                                    </div>

                                    <!-- Group of default radios - option 2 -->
                                    <div class="custom-control custom-radio">
                                        <input type="radio" value="Female" class="custom-control-input" id="defaultGroupExample2" name="gender" <?php if(($subscriber->gender)=='Female'): ?> checked <?php else: ?> <?php endif; ?> >
                                        <label class="custom-control-label" for="defaultGroupExample2">Female</label>
                                    </div>

                                    <!-- Group of default radios - option 3 -->
                                    <div class="custom-control custom-radio">
                                        <input name="Other" type="radio" class="custom-control-input" id="defaultGroupExample3" name="gender" <?php if(($subscriber->gender)=='Other'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="defaultGroupExample3">Other</label>
                                    </div>

                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Resident Address  </label>
                                    <span class="requierd-star"></span>

                                    <textarea name="residentaddress" type="text" class="form-control"
                                              required autocomplete="residentaddress" autofocus><?php echo e($subscriber->residentaddress); ?></textarea>
                                    <!-- <select id="inputState" class="form-control">
                                      <option selected>Choose...</option>
                                      <option>...</option>
                                    </select> -->
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Permanent Address</label>
                                    <span class="requierd-star"></span>
                                    <textarea name="permanentaddress" type="text" class="form-control"
                                              required autocomplete="permanentaddress" autofocus><?php echo e($subscriber->permanentaddress); ?></textarea>
                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Duel Nationality</label>
                                    <span class="requierd-star"></span>
                                    <div class="custom-control custom-radio">
                                        <input name="duelnationality" type="radio" class="custom-control-input" id="defaultGroupExample21" value="Yes" <?php if(($subscriber->duelnationality)=='Yes'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="defaultGroupExample21">Yes</label>
                                    </div>

                                    <!-- Group of default radios - option 3 -->
                                    <div class="custom-control custom-radio">
                                        <input  name="duelnationality" type="radio" class="custom-control-input" id="defaultGroupExample5" value="No" <?php if(($subscriber->duelnationality)=='No'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="defaultGroupExample5">No</label>
                                    </div>

                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> District </label>
                                    <select name="district" class="form-control" required><option selected><?php echo e($subscriber->district); ?><option>Choose...</option> <option>Dhaka</option><option>Faridpur</option><option>Gazipur</option><option>Gopalganj</option><option>Jamalpur</option><option>Kishoreganj</option><option >Madaripur</option><option>Manikganj</option><option>Munshiganj</option><option>Mymensingh</option><option>Narayanganj</option><option>Narsingdi</option><option>Netrokona</option><option>Rajbari</option><option>Shariatpur</option><option>Sherpur</option><option>Tangail</option><option>Bogura</option><option>Joypurhat</option><option>Naogaon</option><option>Natore</option><option>Chapainawabganj</option><option>Pabna</option><option>Rajshahi</option><option>Sirajgonj</option><option>Dinajpur</option><option>Gaibandha</option><option>Kurigram</option><option">Lalmonirhat</option><option>Nilphamari</option><option>Panchagarh</option><option>Rangpur</option><option>Thakurgaon</option><option>Barguna</option><option>Barishal</option><option>Bhola</option><option>Jhalokati</option><option>Patuakhali</option><option>Pirojpur</option><option">Bandarban</option><option>Brahmanbaria</option><option>Chandpur</option><option>Chattogram</option><option>Cumilla</option><option>Cox's Bazar</option><option>Feni</option><option>Khagrachhari</option><option>Lakshmipur</option><option>Noakhali</option><option>Rangamati</option><option>Habiganj</option><option>Moulvibazar</option><option>Sunamganj</option><option>Sylhet</option><option>Bagerhat</option><option>Chuadanga</option><option>Jashore</option><option>Jhenaidah</option><option>Khulna</option><option>Kushtia</option><option>Magura</option><option>Meherpur</option><option>Narail</option><option>Satkhira</option></select>
                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Postal Code</label>
                                    <span class="requierd-star"></span>
                                    <input name="postalcode" type="text" class="form-control"
                                           value="<?php echo e($subscriber->postalcode); ?>" required autocomplete="postalcode" autofocus>
                                    <?php $__errorArgs = ['postalcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Facebook I'd Link </label>
                                    <span class="requierd-star"></span>
                                    <input name="facebook" type="text" class="form-control"
                                           value="<?php echo e($subscriber->facebook); ?>" required autocomplete="facebook" autofocus>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Contact Number </label>
                                    <span class="requierd-star"></span>
                                    <input name="contact" type="text" class="form-control"
                                           value="<?php echo e($subscriber->contact); ?>" required autocomplete="contact" autofocus>
                                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">E-mail Address  </label>
                                    <span class="requierd-star"></span>
                                    <input name="email" type="text" class="form-control"
                                           value="<?php echo e($subscriber->email); ?>" required autocomplete="email" autofocus>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p style="color:#f00;font-weight:500;"><?php echo e($message); ?></p>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Facebook WE follower since</label>
                                    <span class="requierd-star"></span>
                                    <input name="since" type="text" class="form-control"
                                           value="<?php echo e($subscriber->since); ?>" required autocomplete="since" autofocus>
                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Blood Group </label>
                                    <span class="requierd-star"></span>
                                    <select id="inputState" name="bloodgroup" class="form-control">
                                        <option selected><?php echo e($subscriber->bloodgroup); ?></option>
                                        <option selected>A+</option>
                                        <option>B+</option>
                                        <option>O+</option>
                                        <option>AB+</option>
                                        <option>B-</option>
                                    </select>

                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Interested in Donate Blood?  </label>
                                    <span class="requierd-star"></span>
                                    <input name="donateblood" type="text" class="form-control"
                                           value="<?php echo e($subscriber->donateblood); ?>" required autocomplete="donateblood" autofocus>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">National Identity/Birth Certificate No </label>
                                    <span class="requierd-star"></span>
                                    <input name="nid" type="text" class="form-control"
                                           value="<?php echo e($subscriber->nid); ?>" required autocomplete="nid" autofocus>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Which on You have </label>
                                    <span class="requierd-star"></span>


                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form101" name="certificate" value="NID" <?php if(($subscriber->certificate)=='NID'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form101">NID</label>
                                    </div>

                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form201" name="certificate" value="BIRTH" <?php if(($subscriber->certificate)=='BIRTH'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form201">Birth Certificate</label>
                                    </div>


                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Marital Status </label>
                                    <span class="requierd-star"></span>


                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form10111" name="maritalstatus" value="Married" <?php if(($subscriber->maritalstatus)=='Married'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form10111">Married</label>
                                    </div>

                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form20112121" name="maritalstatus" value="Unmarried" <?php if(($subscriber->maritalstatus)=='Unmarried'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form20112121">Unmarried</label>
                                    </div>
                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form301" name="maritalstatus" value="Widow" <?php if(($subscriber->maritalstatus)=='Widow'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form301">Widow</label>
                                    </div>

                                    <div class="custom-control custom-radio">
                                        <input type="radio" class="custom-control-input" id="form401" name="maritalstatus" value="Divorce" <?php if(($subscriber->maritalstatus)=='Divorce'): ?> checked <?php else: ?> <?php endif; ?>>
                                        <label class="custom-control-label" for="form401">Divorce</label>
                                    </div>



                                </div>


                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Detail of Passport Number (If any)</label>

                                    <input name="passport" type="text" class="form-control" value="<?php echo e($subscriber->passport); ?>" required autocomplete="passport" autofocus>
                                </div>


                                <!-- <div class="col-md-6 mb-6">
                                   <label for="validationServer013">National Identity/Birth Certificate No </label>
                                   <span class="requierd-star"></span>
                                   <input type="text" class="form-control"
                                     required>
                                </div> -->
                            </div>
                        </fieldset>

                        <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>


                    </div>
                    </form>



                </div>
            </div>
        </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\server\htdocs\WE_software\30.12.20\29.12.20\WE\resources\views/subscriber/PersonalInformation.blade.php ENDPATH**/ ?>