
<?php $__env->startSection('title'); ?>
    <title>All Product | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>



    <!--Start:  Search Product Category -->
    <section class="statis text-center content">
        <div class="container-fluid">

            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="search">
                        <input class="form-control search-input" id="myInput" type="text" placeholder="Search Product Caregory">
                    </div>
                </div>
            </div>
            <div class="row main">


            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    // Get the stock quantity for the current product
                    $stockQuantity = \App\Models\StockIn::where('warehouseId', Auth::user()->warehouse)
                        ->where('productId', $product->id)
                        ->sum('quantity');
                ?>

                <?php if($stockQuantity > 0): ?> <!-- Check if stock quantity is greater than 0 -->
                    <div class="col-md-2 col-4 searchBox">
                        <div class="sr-category-card text-center align-items-center">
                            <a href="<?php echo e(route('cat.prod.single', $product->id)); ?>">
                                <div class="sr-category-product">
                                    <img style="height:120px; width: 120px;" src="<?php echo e(asset('uploads/products')); ?>/<?php echo e($product->photo); ?>" class="img-fluid cat-image">
                                </div>

                                <div class="sr-category-name">
                                    <h3><?php echo e($product->name); ?></h3>
                                    <h5><?php echo e(\App\Models\Category::where('id', $product->categoryId)->first()->name); ?></h5>
                                    <div class="stock-price">
                                        <p>Stock (<span><?php echo e($stockQuantity); ?></span>)</p>
                                        <p>Price <strong><?php echo e($product->price); ?></strong> Tk.</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>

        </div>
        </div>
    </section>

    <script type="text/javascript">
        // get input field and add 'keyup' event listener
        let searchInput = document.querySelector('.search-input');
        searchInput.addEventListener('keyup', search);

        // get all title
        let titles = document.querySelectorAll('.main .searchBox');
        let searchTerm = '';
        let tit = '';


        function search(e) {
            // get input fieled value and change it to lower case
            searchTerm = e.target.value.toLowerCase();

            titles.forEach((title) => {
                // navigate to p in the title, get its value and change it to lower case
                tit = title.textContent.toLowerCase();
                // it search term not in the title's title hide the title. otherwise, show it.
                tit.includes(searchTerm) ? title.style.display = 'block' : title.style.display = 'none';
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\15.10.24\resources\views/subadmin/order/cat_pro.blade.php ENDPATH**/ ?>