
<?php $__env->startSection('title'); ?>
    <title><?php echo e($subscriber->entrepreneur_name); ?>'s  Details| Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Personal Details</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Personal Information </small></legend>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Entrepreneur’s Name </label>
                                    <p><?php echo e($subscriber->entrepreneur_name); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Father’s Name </label>
                                    <p><?php echo e($subscriber->fname); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Mother's Name </label>
                                    <p><?php echo e($subscriber->mname); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Date Of Birth </label>
                                    <p><?php echo e($subscriber->dob); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Gender </label>
                                    <p><?php echo e($subscriber->gender); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Resident Address </label>
                                    <p><?php echo e($subscriber->residentaddress); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Permanent Address </label>
                                    <p><?php echo e($subscriber->permanentaddress); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Duel Nationality</label>
                                    <p><?php echo e($subscriber->duelnationality); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">District</label>
                                    <p><?php echo e($subscriber->district); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Postal Code</label>
                                    <p><?php echo e($subscriber->postalcode); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Facebook I'd Link</label>
                                    <p><?php echo e($subscriber->facebook); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Contact Number</label>
                                    <p><?php echo e($subscriber->contact); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">E-mail Address</label>
                                    <p><?php echo e($subscriber->email); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Facebook WE follower since</label>
                                    <p><?php echo e($subscriber->since); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Blood Group</label>
                                    <p><?php echo e($subscriber->bloodgroup); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Interested in Donate Blood?</label>
                                    <p><?php echo e($subscriber->donateblood); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Interested in Donate Blood?</label>
                                    <p><?php echo e($subscriber->donateblood); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">National Identity/Birth Certificate No</label>
                                    <p><?php echo e($subscriber->certificate); ?> : <?php echo e($subscriber->nid); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Marital Status</label>
                                    <p><?php echo e($subscriber->maritalstatus); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Detail of Passport Number (If any)</label>
                                    <p><?php echo e($subscriber->passport); ?></p>
                                </div>

                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Details of Family</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Details of Family </small></legend>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Name Of Spouse/Guardian </label>
                                    <p><?php echo e($subscriber->spouse_guardian); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Contact Number of Spouse/Guardian </label>
                                    <p><?php echo e($subscriber->spouse_guardian_contact); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Occupation of Spouse/Guardian </label>
                                    <p><?php echo e($subscriber->occupation_spouse_guardian); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> How Many Children do you have? </label>
                                    <p><?php echo e($subscriber->children); ?></p>
                                </div>

                            </div>
                        </fieldset>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Categories and Photos</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Categories and Photos </small></legend>
                            <div class="form-row">

                                <div class="col-md-6 mb-6">
                                    <div class="form-group col-10">
                                        
                                        
                                        
                                        <div class="select-cusom-margin" style="margin-bottom: 10px;">
                                            <?php echo e($subscriber->category1); ?>

                                        </div>

                                        <?php if($subscriber->product1): ?>
                                            <img src="<?php echo e(asset('uploads/product1/'.$subscriber->product1)); ?>" class="img-thumbnail" width="100" height="100" />

                                        <?php endif; ?>
                                    </div><br>
                                    <div class="invalid-feedback"></div>
                                    <div class="col-md-10 mb-12">
                                        <?php echo e($subscriber->details1); ?>

                                    </div>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <div class="form-group col-10">
                                        
                                        
                                        
                                        <div class="select-cusom-margin" style="margin-bottom: 10px;">
                                            <?php echo e($subscriber->category2); ?>

                                        </div>
                                        <?php if($subscriber->product2): ?>
                                            <img src="<?php echo e(asset('uploads/product2/'.$subscriber->product2)); ?>" class="img-thumbnail" width="100" height="100" />
                                        <?php endif; ?>
                                    </div><br>
                                    <div class="invalid-feedback"></div>
                                    <div class="col-md-10 mb-12">
                                        <?php echo e($subscriber->details2); ?>

                                    </div>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <div class="form-group col-10">
                                        
                                        
                                        
                                        <div class="select-cusom-margin" style="margin-bottom: 10px;">
                                            <?php echo e($subscriber->category3); ?>

                                        </div>
                                        <?php if($subscriber->product3): ?>
                                            <img src="<?php echo e(asset('uploads/product3/'.$subscriber->product3)); ?>" class="img-thumbnail" width="100" height="100" />
                                        <?php endif; ?>
                                    </div><br>
                                    <div class="invalid-feedback"></div>
                                    <div class="col-md-10 mb-12">
                                        <?php echo e($subscriber->details3); ?>

                                    </div>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <div class="form-group col-10">
                                        
                                        
                                        
                                        <div class="select-cusom-margin" style="margin-bottom: 10px;">
                                            <?php echo e($subscriber->category4); ?>

                                        </div>
                                        <?php if($subscriber->product4): ?>
                                            <img src="<?php echo e(asset('uploads/product4/'.$subscriber->product4)); ?>" class="img-thumbnail" width="100" height="100" />
                                        <?php endif; ?>
                                    </div><br>
                                    <div class="invalid-feedback"></div>
                                    <div class="col-md-10 mb-12">
                                        <?php echo e($subscriber->details4); ?>

                                    </div>
                                </div>



                            </div>
                        </fieldset>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Detail of Income & Income Tax</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Detail of Income & Income Tax </small></legend>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Average Annual Income </label>
                                    <p><?php echo e($subscriber->income); ?></p>
                                </div>



                            </div>
                        </fieldset>


                    </div>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">COMPANY INFORMATION</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">COMPANY INFORMATION </small></legend>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Name </label>
                                    <p><?php echo e($subscriber->company_name); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Office Address  </label>
                                    <p><?php echo e($subscriber->office_address); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">District  </label>
                                    <p><?php echo e($subscriber->office_district); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Postal Code  </label>
                                    <p><?php echo e($subscriber->office_postal); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Phone No. (Office) </label>
                                    <p><?php echo e($subscriber->office_phone); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Mobile </label>
                                    <p><?php echo e($subscriber->office_mobile); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Email ID </label>
                                    <p><?php echo e($subscriber->company_email); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Website (If any) </label>
                                    <p><?php echo e($subscriber->website); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Facebook Page Name </label>
                                    <p><?php echo e($subscriber->company_facebook); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Facebook Page Link </label>
                                    <p><?php echo e($subscriber->companypagelink); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Facebook Group Name: (if any) </label>
                                    <p><?php echo e($subscriber->facebook_group); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Linked-in Link : (if any) </label>
                                    <p><?php echo e($subscriber->company_linkedin); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Product Category </label>
                                    <p><?php echo e($subscriber->product_category); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Product Name </label>
                                    <p><?php echo e($subscriber->product); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Company Establishment Year </label>
                                    <p><?php echo e($subscriber->company_year); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Annual Average Turnover </label>
                                    <p><?php echo e($subscriber->turnover); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Monthly Average Order</label>
                                    <p><?php echo e($subscriber->monthly_order); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Business Channel</label>
                                    <p><?php echo e($subscriber->channel); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Are you interested in Export?</label>
                                    <p><?php echo e($subscriber->export); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">WE Involvement (Short Details)</label>
                                    <p><?php echo e($subscriber->involvement); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Joining Date</label>
                                    <p><?php echo e($subscriber->joining_date); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Joining Date</label>
                                    <p><?php echo e($subscriber->joining_date); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Total Sale from WE</label>
                                    <p><?php echo e($subscriber->total_sale); ?></p>
                                </div>
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013">Total Post in WE </label>
                                    <p><?php echo e($subscriber->totalinpost); ?></p>
                                </div>

                            </div>
                        </fieldset>



                    </div>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Reference Number</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Reference Number</small></legend>
                            <div class="form-row">
                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Name of Reference 1 </label>
                                    <p><?php echo e($subscriber->ref1); ?></p>
                                </div>

                                <div class="col-md-6 mb-6">
                                    <label for="validationServer013"> Name of Reference 2 </label>
                                    <p><?php echo e($subscriber->ref2); ?></p>
                                </div>

                            </div>
                        </fieldset>


                    </div>


                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Subscriber Number</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('subscriber.number',$subscriber->id)); ?>">
                            
                            <?php echo csrf_field(); ?>
                            <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                                <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Subscriber Number</small></legend>
                                <div class="form-row">
                                    <div class="col-md-6 mb-6">

                                        <div class="col-md-6 mb-6">
                                            <label for="validationServer013">Subscriber Number </label>
                                            <span class="requierd-star"></span>
                                            <div class="custom-control custom-radio">
                                                
                                                <input name="subscriber_number" type="text" class="form-control" placeholder="Subscriber Number" value="<?php echo e($subscriber->subscriber_number); ?>" required="" autocomplete="subscriber_number" autofocus="">
                                                <input name="subscriber_email" type="hidden" class="form-control" placeholder="Subscriber Email" value="<?php echo e($subscriber->email); ?>" required="" autocomplete="subscriber_number" autofocus="">

                                            </div>


                                        </div>


                                    </div>
                            </fieldset>





                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                        </form>

                    </div>


                </div>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/weforumbd/public_html/resources/views/superadmin/paid_details.blade.php ENDPATH**/ ?>