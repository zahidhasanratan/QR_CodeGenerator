
<?php $__env->startSection('title'); ?>
    <title>Payment History | Non Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Payment History</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>


                    <div class="card-body">
                        <div class="form-row">

                            <?php if(isset($subscription_fees_submit->userid)): ?>
                                <div class="col-md-6 mb-12 mb-6">
                                    <div class="card card-stats card-payment-custom">
                                        <div class="payment-history-box">
                                            <h2 class="main-title-history">Subscription Fee</h2>
                                            <h3 class="pay-titl-1"> #Success</h3>
                                            <h3 class="pay-titl-2"> <?php echo e(Carbon\Carbon::parse($subscription_fees_submit->created_at)->format('Y-m-d')); ?></h3>
                                            <h3 class="pay-titl-2">Invoice: #SPF<?php echo e($subscription_fees_submit->id); ?></h3>
                                            <h3 class="pay-titl-1"> <?php echo e($subscription_fees_submit->amount); ?> Tk.</h3>
                                        </div>
                                        <div class="history-button">
                                            <ul>
                                                <li><a href="<?php echo e(route('nonSubscriber_payment_Receipt',$subscription_fees_submit->id)); ?>"> Recipt</a></li>
                                                <li><a href="<?php echo e(route('nonSubscriber_payment_invoice',$subscription_fees_submit->id)); ?>"> Invoice</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php $__currentLoopData = $seminar_paid_subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar_paid_subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 mb-12 mb-6">
                                    <div class="card card-stats card-payment-custom">
                                        <div class="payment-history-box">
                                            <h2 class="main-title-history"><?php echo e(\App\Models\Seminar::where(['id' => $seminar_paid_subscriber->seminar_id])->pluck('title')->first()); ?></h2>
                                            <h3 class="pay-titl-1"> #Success</h3>
                                            <h3 class="pay-titl-2"> <?php echo e(Carbon\Carbon::parse($seminar_paid_subscriber->created_at)->format('Y-m-d')); ?></h3>
                                            <h3 class="pay-titl-2">Invoice: #SPF<?php echo e($seminar_paid_subscriber->seminar_id); ?><?php echo e($seminar_paid_subscriber->userid); ?></h3>
                                            <h3 class="pay-titl-1"> <?php echo e($seminar_paid_subscriber->amount); ?> Tk.</h3>
                                        </div>
                                        <div class="history-button">
                                            <ul>
                                                <li><a href="<?php echo e(route('nonSeminar_payment_Receipt',$seminar_paid_subscriber->seminar_id)); ?>"> Recipt</a></li>
                                                <li><a href="<?php echo e(route('nonSeminar_payment_invoice',$seminar_paid_subscriber->seminar_id)); ?>"> Invoice</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                        </div>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.3.21\24.3.21\resources\views/nonsubscriber/PaymentHistory.blade.php ENDPATH**/ ?>