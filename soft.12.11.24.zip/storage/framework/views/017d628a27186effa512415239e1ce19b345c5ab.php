Hello <?php echo e($email_data['name']); ?>

<br><br>
Welcome to Our Website!
<br>
Please click the below link to verify your email and activate your account!
<br><br>
<a href="http://127.0.0.1:8000/verify?code=<?php echo e($email_data['verification_code']); ?>">Click Here!</a>

<br><br>
Thank you!
<br>
woforumbd.com<?php /**PATH H:\xamp.7.4\htdocs\WE\15.2.21\Software\WE\resources\views/mail/signup-email.blade.php ENDPATH**/ ?>