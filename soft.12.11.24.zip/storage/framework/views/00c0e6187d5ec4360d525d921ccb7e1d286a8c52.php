
<?php $__env->startSection('title'); ?>
    <title>Certificate | Non Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">


                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Certificate</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>


                    <div class="card-body">
                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "> </small></legend>

                            <div class="form-row">

                                
                                
                                <?php if(isset($subscription_fees_submit->userid)): ?>
                                    <?php $__currentLoopData = $subscription_fees_submit_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription_fees_submit_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        
                                        <div class="col-md-12 mb-12 mb-6">
                                            <div class="alert alert-info alert-info-custom">
                                                <a href="<?php echo e(route('nonSubscriber_certificate_details',$subscription_fees_submit_all->year)); ?>" class="btn btn-xs danger pull-right btn-custom-payment">View</a>
                                                Subscriber Certificate <strong style="color: #8e24aa; float: right; padding-right: 25px">  Subscriber Certificate <?php echo e($subscription_fees_submit_all->year); ?></strong>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php $__currentLoopData = $seminar_paid_subscriber; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seminar_paid_subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(date('Y-m-d') > (\App\Models\Seminar::where(['id' => $seminar_paid_subscriber->seminar_id])->pluck('eventdate')->first())): ?>

                                        
                                        <div class="col-md-12 mb-12 mb-6">
                                            <div class="alert alert-info alert-info-custom">
                                                <a href="<?php echo e(route('nonSeminar_certificate_details',$seminar_paid_subscriber->seminar_id)); ?>" class="btn btn-xs danger pull-right btn-custom-payment">View</a>
                                                <?php echo e(\App\Models\Seminar::where(['id' => $seminar_paid_subscriber->seminar_id])->pluck('title')->first()); ?> <?php echo e(\App\Models\Seminar::where(['id' => $seminar_paid_subscriber->seminar_id])->pluck('title')->first()); ?> <strong style="color: #8e24aa; float: right; padding-right: 25px">   Certificate </strong>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                                
                                

                                
                                



                            </div>
                        </fieldset>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tflviici/public_html/resources/views/nonsubscriber/Certificate.blade.php ENDPATH**/ ?>