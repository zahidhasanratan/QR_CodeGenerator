
<?php $__env->startSection('title'); ?>
    <title>Dashboard | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <?php echo $__env->make('nonsubscriber.redirection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php if(isset($subscriber->subscriber_id) == Auth::id() and ($subscriber->status !='active')): ?>
        <div class="card-header card-header-primary" style="color:red">
            <h3>We are Reviewing Your Profile...</h3>
            <p>We will inform you soon.</p>
        </div>
    <?php endif; ?>



        <div class="container-fluid">
            <div class="row">
                 <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="https://wedelivery.net" target="_blank">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">send</i>
                                </div>
                                <p class="card-category">WE Delivery</p>
                            </div>
                        </a>
                    </div>
                </div>
 <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="<?php echo e(route('non-Subscriber.Seminar')); ?>">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">language</i>
                                </div>
                                <p class="card-category">Seminar & Workshop</p>
                            </div>
                        </a>
                    </div>
                </div>
                 <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="<?php echo e(route('nonCertificate')); ?>">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">note</i>
                                </div>
                                <p class="card-category">Certificate</p>
                            </div>
                        </a>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="<?php echo e(route('nonPayment.history')); ?>">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">language</i>
                                </div>
                                <p class="card-category">Payment History</p>
                            </div>
                        </a>
                    </div>
                </div>







            </div>


            <div class="row">
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-success">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Announcement</h4>
                            <?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p style="text-align: justify; padding-bottom: 10px" class="card-category"><?php echo e($loop->iteration); ?>, <?php echo e($announcement->short); ?></p>
                                <a href="<?php echo e(route('nonannouncement.details',$announcement->slug)); ?>">View Details</a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="dasboard-services">
                                <a style="float:right;text-decoration: none;color: red;font-size: 15px;" href="<?php echo e(route('nonannouncement.all')); ?>">View All Announcement</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-warning">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Events</h4>
                            <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p style="text-align: justify; padding-bottom: 10px" class="card-category"><?php echo e($loop->iteration); ?>, <?php echo e($event->short); ?></p>
                                <a href="<?php echo e(route('nonevent.details',$event->slug)); ?>">View Details</a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="dasboard-services">
                                <a style="float:right;text-decoration: none;color: red;font-size: 15px;" href="<?php echo e(route('nonevent.all')); ?>">View All Events</a>
                            </div>

                        </div>

                        <!-- <div class="card-footer">
                          <div class="stats">
                            <i class="material-icons">access_time</i> campaign sent 2 days ago
                          </div>
                        </div> -->
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-danger">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Notices</h4>
                           <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="text-align: justify; padding-bottom: 10px" class="card-category"><?php echo e($notice->short); ?></p>
                               <a href="<?php echo e(route('nonnotice.details',$notice->slug)); ?>">View More</a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="dasboard-services">
                                <a style="float:right;text-decoration: none;color: red;font-size: 15px;" href="<?php echo e(route('nonnotice.all')); ?>">View All Notices</a>
                            </div>
                        </div>
                        <!-- <div class="card-footer">
                          <div class="stats">
                            <i class="material-icons">access_time</i> campaign sent 2 days ago
                          </div>
                        </div> -->
                    </div>
                </div>
            </div>






    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nonsubscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\14.3.22\resources\views/nonsubscriber/dashboard.blade.php ENDPATH**/ ?>