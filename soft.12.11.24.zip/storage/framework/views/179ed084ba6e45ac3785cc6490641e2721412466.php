
<?php $__env->startSection('title'); ?>
    <title>Subscription Fees | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Edit Subscription Fees</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">

                        <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                            <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold ">Edit Subscription Fees </small></legend>

                            <div class="form-row">
                                <form role="form" method="post" action="<?php echo e(route('subscription_fees.update',$subscription_fees->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013"> Title </label>
                                        <span class="requierd-star"></span>
                                        <input class="form-control" name="title" value="<?php echo e($subscription_fees->title); ?>" placeholder="Title"  required/>
                                    </div>

                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013"> Year </label>
                                        <span class="requierd-star"></span>
                                        <input class="form-control" name="year" value="<?php echo e($subscription_fees->year); ?>" placeholder="Year" required/>
                                    </div>

                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013">Description</label>
                                        <span class="requierd-star"></span>
                                        <textarea class="form-control ckeditor" rows="3" name="description"><?php echo e($subscription_fees->description); ?></textarea>
                                    </div>

                                    <div class="col-md-12 mb-12">
                                        <label for="validationServer013"> Fees</label>
                                        <span class="requierd-star"></span>
                                        <input class="form-control" name="fees" value="<?php echo e($subscription_fees->fees); ?>" placeholder="Fees" required />

                                    </div>

                                    
                                        
                                        
                                    

                                    
                                        

                                        
                                    


                                    <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                                </form>

                            </div>
                        </fieldset>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tflviici/public_html/resources/views/superadmin/subscription/subscriptionedit.blade.php ENDPATH**/ ?>