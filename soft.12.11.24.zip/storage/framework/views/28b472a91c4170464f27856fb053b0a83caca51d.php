
<?php $__env->startSection('title'); ?>
    <title>Reports  | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>


    <div class="container-fluid">
        <div class="row">

            <div class="card">
                <div class="card-header card-header-primary">
                    <h4 style="text-align: center;" class="card-title">Repoart Search</h4>
                    <!-- <p class="card-category">Complete your profile</p> -->
                </div>


                <div class="card-body">
                    <div class="filter-search-sec">

                        <form method="POST" action="<?php echo e(route('report.search')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group form-group-custom-2 row">

                                <label for="email_address" class="col-md-3 col-form-label text-md-right" style="padding-top: 40px">Search By Date </label>

                                <div class="col-md-4">
                                    <div class="form-group form-group-custom-2">
                                        <label class="control-label">From</label>
                                        <div class="input-group date">
                                            <input name="from" class="form-control" type="date" />

                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-4">
                                    <div class="form-group form-group-custom-2">
                                        <label class="control-label">To</label>
                                        <div class="input-group date">
                                            <input name="to" class="form-control" type="date" />

                                        </div>
                                    </div>
                                </div>

                                <label for="email_address" class="col-md-3 col-form-label text-md-right">Category </label>


                                <div class="col-md-2">
                                    <div class="form-group form-group-custom-2">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" id="defaultGroupExample15555" name="category" value="1" checked>
                                            <label class="custom-control-label" for="defaultGroupExample15555">Subscriber</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group form-group-custom-2">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" id="defaultGroupExample10001" name="category" value="2">
                                            <label class="custom-control-label" for="defaultGroupExample10001">Non Subscriber</label>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-md-4">
                                    <div class="form-group form-group-custom-2">
                                        <!-- <label class="control-label">Select District</label> -->
                                        <div class="custom-control">

                                            <select name="district" class="form-control search-slt" id="exampleFormControlSelect1">
                                                <option selected="selected" value="">All District</option>
                                                <option>Bagerhat</option>
                                                <option>Bandarban</option>
                                                <option>Barguna</option>
                                                <option>Barishal</option>
                                                <option>Bhola</option>
                                                <option>Bogura</option>
                                                <option>Brahmanbaria</option>
                                                <option>Chandpur</option>
                                                <option>Chapainawabganj</option>
                                                <option>Chattogram</option>
                                                <option>Chuadanga</option>
                                                <option>Coxsbazar</option>
                                                <option>Cumilla</option>
                                                <option>Dhaka</option>
                                                <option>Dinajpur</option>
                                                <option>Faridpur</option>
                                                <option>Feni</option>
                                                <option>Gaibandha</option>
                                                <option>Gazipur</option>
                                                <option>Gopalganj</option>
                                                <option>Habiganj</option>
                                                <option>Jamalpur</option>
                                                <option>Jashore</option>
                                                <option>Jhalakathi</option>
                                                <option>Jhenaidah</option>
                                                <option>Joypurhat</option>
                                                <option>Khagrachhari</option>
                                                <option>Khulna</option>
                                                <option>Kishoreganj</option>
                                                <option>Kurigram</option>
                                                <option>Kushtia</option>
                                                <option>Lakshmipur</option>
                                                <option>Lalmonirhat</option>
                                                <option>Madaripur</option>
                                                <option>>Magura</option>
                                                <option>Manikganj</option>
                                                <option>Meherpur</option>
                                                <option>Moulvibazar</option>
                                                <option>Munshiganj</option>
                                                <option>Mymensingh</option>
                                                <option>Naogaon</option>
                                                <option>Narail</option>
                                                <option>Narayanganj</option>
                                                <option>Narsingdi</option>
                                                <option>Natore</option>
                                                <option>Netrokona</option>
                                                <option>Nilphamari</option>
                                                <option>Noakhali</option>
                                                <option>Pabna</option>
                                                <option>Panchagarh</option>
                                                <option>Patuakhali</option>
                                                <option>Pirojpur</option>
                                                <option>Rajbari</option>
                                                <option>Rajshahi</option>
                                                <option>Rangamati</option>
                                                <option>Rangpur</option>
                                                <option>Satkhira</option>
                                                <option>Shariatpur</option>
                                                <option>Sherpur</option>
                                                <option>Sirajganj</option>
                                                <option>Sunamganj</option>
                                                <option>Sylhet</option>
                                                <option>Tangail</option>
                                                <option>Thakurgaon</option>
                                            </select>

                                        </div>
                                    </div>
                                </div>



                                <label for="email_address" class="col-md-3 col-form-label text-md-right">Annual Income</label>


                                <div class="col-md-3">
                                    <div class="form-group form-group-custom-2">
                                        <!-- <label class="control-label">Select District</label> -->
                                        <div class="custom-control">

                                            <select name="totalincome" class="form-control search-slt" id="exampleFormControlSelect1">
                                                <option selected="selected" value="">Select Annual Income</option>
                                                <option value="10000">0 - 10k</option>
                                                <option value="100000">10k - 1 Lac </option>
                                                <option value="1000000">1 Lac - 10 Lac </option>
                                                <option value="5000000">10 Lac - 50 Lac </option>

                                            </select>

                                        </div>
                                    </div>
                                </div>

                                <label for="email_address" class="col-md-2 col-form-label text-md-right">Total Post WE</label>


                                <div class="col-md-3">
                                    <div class="form-group form-group-custom-2">
                                        <!-- <label class="control-label">Select District</label> -->
                                        <div class="custom-control">

                                            <select name="totalpost" class="form-control search-slt" id="exampleFormControlSelect1">
                                                <option selected="selected" value="">Select Total Post</option>
                                                <option value="100">1 - 100</option>
                                                <option value="200">100 -200 </option>
                                                <option value="300">201 -300 </option>
                                                <option value="500">301 -500 </option>
                                                <option value="1000">501 -1000 </option>


                                            </select>

                                        </div>
                                    </div>
                                </div>



                                <label for="email_address" class="col-md-3 col-form-label text-md-right">Total Sale from WE</label>


                                <div class="col-md-3">
                                    <div class="form-group form-group-custom-2">
                                        <!-- <label class="control-label">Select District</label> -->
                                        <div class="custom-control">

                                            <select name="totalsale" class="form-control search-slt" id="exampleFormControlSelect1">
                                                <option selected="selected" value="">Select Total Sale</option>
                                                <option value="10000">0 - 10k</option>
                                                <option value="100000">10k - 1 Lac </option>
                                                <option value="1000000">1 Lac - 10 Lac </option>
                                                <option value="5000000">10 Lac - 50 Lac </option>


                                            </select>

                                        </div>
                                    </div>
                                </div>

                                


                                
                                
                                
                                
                                
                                
                                
                                





                                <div class="col-md-5">
                                </div>


                                <div class="col-md-6">
                                    <div class="form-group form-group-custom-2" style="margin-top: 31px;float:right;">
                                        <button name="" type="submit" class="btn btn-primary btn-custom"><span>Search</span></button>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group form-group-custom-2" style="margin-top: 31px;float:right">
                                        <button name="xls" value="xls" type="submit" class="btn btn-primary btn-custom"><span>Download .Xls</span></button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </div>

                    <style>
                        .card .table tr td {
                            border-top: none;
                            text-align: center;
                        }
                    </style>

                </div>


            </div>


            <style>
                .filter-search-sec{
                    background: #EBEFF2;
                    padding: 2rem;
                    border-radius: 10px;
                }
                label {
                    color: #393333;
                    display: block;
                    font-weight: 400;
                    margin-bottom: 10px;
                }
                input[type="date" i] {
                    padding: 0 14px;
                }
                .input-group > .input-group-append > .btn, .input-group > .input-group-append > .input-group-text, .input-group > .input-group-prepend:first-child > .btn:not(:first-child), .input-group > .input-group-prepend:first-child > .input-group-text:not(:first-child), .input-group > .input-group-prepend:not(:first-child) > .btn, .input-group > .input-group-prepend:not(:first-child) > .input-group-text {
                    border-top-left-radius: 0;
                    border-bottom-left-radius: 0;
                    margin-top: 0px;
                    border-color: #cec6c6;
                }
                .btn-custom {
                    padding: 7px 45px;
                    text-transform: capitalize;
                }
                .repoart-search{

                    text-align: center;
                    font-size: 40px;
                    color: #3c3636;
                    font-weight: 500;
                }
            </style>
            <div class="col-lg-12">

            </div>
        </div>

        <style>
            .filter-search-sec{
                background: #EBEFF2;
                padding: 2rem;
                border-radius: 10px;
            }
            label {
                color: #393333;
                display: block;
                font-weight: 400;
                margin-bottom: 10px;
            }
            input[type="date" i] {
                padding: 0 14px;
            }
            .input-group > .input-group-append > .btn, .input-group > .input-group-append > .input-group-text, .input-group > .input-group-prepend:first-child > .btn:not(:first-child), .input-group > .input-group-prepend:first-child > .input-group-text:not(:first-child), .input-group > .input-group-prepend:not(:first-child) > .btn, .input-group > .input-group-prepend:not(:first-child) > .input-group-text {
                border-top-left-radius: 0;
                border-bottom-left-radius: 0;
                margin-top: 0px;
                border-color: #cec6c6;
            }
            .btn-custom {
                padding: 7px 45px;
                text-transform: capitalize;
            }
            select, select.form-control {
                -moz-appearance: auto !important;
                -webkit-appearance: auto !important;
            }
        </style>


    </div>
    
        
            
                
                    
                    
                


                
                    
                        
                        

                        
                            
                            

                                
                                
                                
                                
                                
                                
                            
                            
                            
                            
                            

                                
                                
                                
                                
                                
                                
                            
                             





                            
                        
                    

                    
                        
                            
                            
                        
                    

                


            
        
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\server\htdocs\WE\26.3.21export\26.3.21\resources\views/superadmin/report.blade.php ENDPATH**/ ?>