
<?php $__env->startSection('title'); ?>
    <title>Shop List | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title ">All Shop List</h4>
                    </div>

                    <!-- data table -->

                    <div class="table-wrapper">
                        <div class="card-body">

                            <div class="add-button text-right">
                                <a href="<?php echo e(route('shop.create')); ?>" class="btn btn-primary text-capitalize"><span>Add Sr Shop</span></a>
                            </div>

                            <div class="table-responsive">
                                <?php if(session('successMsg') || session('dangerMsg')): ?>
                                    <div class="alert <?php if(session('successMsg')): ?> alert-success <?php else: ?> alert-danger <?php endif; ?> alert-dismissible fade show" role="alert">
                                        <?php echo e(session('successMsg') ?? session('dangerMsg')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <table id="warehouseTable" class="table table-hover" cellspacing="0" width="100%">
                                    <thead class="text-primary">
                                    <tr>
                                        <th> Sl. </th>
                                        <th>Shop Name </th>
                                        <th>Owner Name </th>
                                        <th>Mobile </th>
                                        <th>Address </th>
                                        <th class="text-right">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $srshop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($key+1); ?> </td>
                                            <td> <?php echo e($list->shopName); ?> </td>
                                            <td> <?php echo e($list->ownerName); ?> </td>
                                            <td> <?php echo e($list->Mobile); ?> </td>
                                            <td> <?php echo e($list->Adress); ?> </td>
                                            <td class="td-actions text-right">
                                                <form id="delete-form-<?php echo e($list->id); ?>" action="<?php echo e(route('shop.destroy', $list->id)); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                                <button type="button" onclick="window.location='<?php echo e(route('super.payment.shop', $list->id)); ?>'" rel="tooltip" class="btn btn-primary btn-link btn-sm" title="View Payement Details">
                                                    <i class="material-icons">credit_card</i>
                                                </button>
                                                <button type="button"
                                                        rel="tooltip"
                                                        title="Add Payment"
                                                        class="btn btn-danger btn-link btn-sm"
                                                        data-toggle="modal"
                                                        data-target="#paymentModal"
                                                        data-shop-id="<?php echo e($list->id); ?>"
                                                        data-shop-name="<?php echo e($list->shopName); ?>">
                                                    <i class="material-icons">attach_money</i>
                                                </button>

                                                <button type="button" onclick="window.location='<?php echo e(route('super.list.shop', $list->id)); ?>'" rel="tooltip" class="btn btn-primary btn-link btn-sm" title="View Order list">
                                                    <i class="material-icons">visibility</i>
                                                </button>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- DataTable Initialization Script -->
                    <script>
                        $(document).ready(function() {
                            $('#warehouseTable').DataTable();
                        });
                    </script>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Add Payment</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('payment.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input name="shop_id" id="shopId" type="hidden">

                        <div class="form-row mb-3">
                            <div class="col-md-6">
                                <label>Date</label>
                                <span class="required-star"></span>
                                <input type="date" name="payment_date" class="form-control" id="payment_date" required>
                            </div>

                            <div class="col-md-6">
                                <label for="payment-amount">Amount</label>
                                <span class="required-star"></span>
                                <input type="number" name="amount" class="form-control" id="payment_amount" required placeholder="Enter Amount">
                            </div>

                        </div>

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary"><span>Submit</span></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Trigger modal and populate it with shop data
            $('#paymentModal').on('show.bs.modal', function (event) {
                var button = $(event.relatedTarget); // Button that triggered the modal
                var shopId = button.data('shop-id'); // Extract shop ID
                var shopName = button.data('shop-name'); // Extract shop name

                var modal = $(this);
                modal.find('.modal-title').text('Add Payment for ' + shopName);
                modal.find('#shopId').val(shopId); // Set shop ID in the hidden input
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\20.10.24\resources\views/superadmin/shop/index.blade.php ENDPATH**/ ?>