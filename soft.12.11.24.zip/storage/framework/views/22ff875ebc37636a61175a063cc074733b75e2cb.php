
<?php $__env->startSection('title'); ?>
    <title>Dashboard | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <?php if($subscriber->status != 'active'): ?>
    <div class="card-header card-header-primary" style="color:red">
        <h3>We are Reviwing Your Profile...</h3>
        <p>We will inform you soon.</p>
    </div>


    <?php else: ?>

        <div class="container-fluid">
            <div class="row">

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="personal-information.html">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">content_copy</i>
                                </div>
                                <p class="card-category">Personal Info</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="details-family.html">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">content_copy</i>
                                </div>
                                <p class="card-category">Details of Family</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="payment.html">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">content_copy</i>
                                </div>
                                <p class="card-category">Payment</p>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <a href="seminar-workshop.html">
                            <div class="card-header card-header-warning card-header-icon">
                                <div class="card-icon">
                                    <i class="material-icons">content_copy</i>
                                </div>
                                <p class="card-category">Seminar & Workshop</p>
                            </div>
                        </a>
                    </div>
                </div>



            </div>


            <div class="row">
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-success">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Get Services</h4>
                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">1. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>

                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">2. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>

                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">3. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>


                            </p>
                            <div class="dasboard-services">
                                <!--  -->

                                <!--  -->
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-warning">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Subscriber Events</h4>
                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">1. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>

                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">2. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>

                            <p style="text-align: justify; padding-bottom: 10px" class="card-category">3. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                                tempor incididunt ut labore et dolore magna aliqua. </p>
                        </div>
                        <!-- <div class="card-footer">
                          <div class="stats">
                            <i class="material-icons">access_time</i> campaign sent 2 days ago
                          </div>
                        </div> -->
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-chart">
                        <div class="card-header card-header-danger">

                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Subscriber Notices</h4>
                           <?php $__currentLoopData = $notice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="text-align: justify; padding-bottom: 10px" class="card-category"><?php echo e($notice->short); ?></p>
                               <a href="<?php echo e(route('notice.details',$notice->slug)); ?>">View More</a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <p class="card-category">Last Campaign Performance</p> -->
                        </div>
                        <!-- <div class="card-footer">
                          <div class="stats">
                            <i class="material-icons">access_time</i> campaign sent 2 days ago
                          </div>
                        </div> -->
                    </div>
                </div>
            </div>






    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\27.1.21\Software\WE\resources\views/subscriber/dashboard.blade.php ENDPATH**/ ?>