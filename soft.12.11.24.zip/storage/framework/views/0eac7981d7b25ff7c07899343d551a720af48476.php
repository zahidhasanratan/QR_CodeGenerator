<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('asset/assets/img/sidebar-1.jpg')); ?>">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="<?php echo e(route('subscriber-dashboard')); ?>" class="simple-text logo-normal">
            <img src="<?php echo e(asset('asset/images/logo.png')); ?>">
        </a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav">
            
            <?php if((isset($subscriber->subscriber_id) != Auth::id()) or ($subscriber->step1) != 6): ?>

            <li class="nav-item <?php if(Request::path() =='Non-Subscriber/home' or Request::path() =='Non-Subscriber/second_step' or Request::path() =='Non-Subscriber/third_step'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('nohome')); ?>">
                    <i class="material-icons">face</i>
                    <p>Become Subscriber</p>
                </a>
            </li>


            <?php endif; ?>



            <li class="nav-item <?php if(Request::path() =='Non-Subscriber-Dashboard'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('non-subscriber-dashboard')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>

            
                    
                
                
                    
                    
                
            


            
                    
                
                
                    
                    
                
            


            
                    
                
                
                    
                    
                
            
            
                    
                
                
                    
                    
                
            


            <!--  <li class="nav-item ">
               <a class="nav-link" href="reference.html">
                 <i class="material-icons">bubble_chart</i>
                 <p>Name of Reference</p>
               </a>
             </li> -->

            
                    
                
                
                    
                    
                
            

            
                    
                
                
                    
                    
                
            



            

                
                
                
                
                
                

                <li class="nav-item <?php if(Request::path() =='Non-Subscriber/Payment'): ?>
                        active
                    <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('nonPayment')); ?>">
                        <i class="material-icons">payment</i>
                        <p>Payment </p>
                    </a>
                </li>

                <li class="nav-item <?php if(Request::path() =='Non-Subscriber/Payment-History'): ?>
                        active
                    <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('nonPayment.history')); ?>">
                        <i class="material-icons">language</i>
                        <p>Payment History</p>
                    </a>
                </li>

                <li class="nav-item <?php if(Request::path() =='Non-Subscriber/Certificate'): ?>
                        active
                    <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('nonCertificate')); ?>">
                        <i class="material-icons">note</i>
                        <p>Certificate </p>
                    </a>
                </li>
                
                
                
                
                
                

                <li class="nav-item <?php if(Request::path() =='Non-Subscriber/Seminar'): ?>
                        active
                    <?php endif; ?>">
                    <a class="nav-link" href="<?php echo e(route('non-Subscriber.Seminar')); ?>">
                        <i class="material-icons">language</i>
                        <p> Seminar / Workshop / Training</p>
                    </a>
                </li>

                
                
                
                
                
                

                
                
                
                
                
                

            


            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                    <i class="material-icons">logout</i>
                    <p>logout</p>
                </a>
            </li>


            <!-- <li class="nav-item active-pro ">
              <a class="nav-link" href="./upgrade.html">
                <i class="material-icons">unarchive</i>
                <p>logout</p>
              </a>
            </li> -->
        </ul>
    </div>

</div><?php /**PATH H:\xamp.7.4\htdocs\WE\29.3.21\28.3.21\resources\views/layouts/partial/nonsidebar.blade.php ENDPATH**/ ?>