<p>Hi, Your Subscriber Number is <?php echo e($data['subscriber_number']); ?></p>
<br>



You can reset your password from this <a href="http://weforumbd.org/password/reset">link</a>
<br><br>



<br><br>
Thank you!
<br>
weforumbd.org<?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\14.3.22\resources\views/mail/subscriber_number.blade.php ENDPATH**/ ?>