
<?php $__env->startSection('title'); ?>
    <title>Seminar/Worksho/Training | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Subscription Fee</h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>


                    <div class="card-body">

                        <form role="form" method="post" action="<?php echo e(route('subscriptionfee.store')); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="hRPkp4LTcnONgc8ra8gXdmdxmbhrsunvPNSqkd2V">                                    <div class="col-md-12 mb-12">
                                <label for="validationServer013"> Title </label>
                                <span class="requierd-star"></span>
                                <span class="bmd-form-group is-filled"><input class="form-control" name="title" placeholder="Title" required></span>
                            </div>

                            <div class="col-md-12 mb-12">
                                <label for="validationServer013"> Year </label>
                                <span class="requierd-star"></span>
                                <span class="bmd-form-group is-filled"><input class="form-control" name="year" placeholder="Year" required></span>
                            </div>

                            <div class="col-md-12 mb-12">
                                <label for="validationServer013">Description</label>
                                <span class="requierd-star"></span>
                                <span class="bmd-form-group is-filled">
                                    <textarea class="form-control ckeditor" rows="3" name="description" style="visibility: hidden; display: none;"></textarea>
                            </div>

                            <div class="col-md-12 mb-12">
                                <label for="validationServer013"> Fees</label>
                                <span class="requierd-star"></span>
                                <span class="bmd-form-group is-filled"><input class="form-control" name="fees" placeholder="Fees" required></span>

                            </div>



                            <div class="form-group col-lg-12 text-center"><button type="submit" class="btn btn-primary"><span>Submit</span></button></div>
                        </form>

                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.3.21\24.3.21\resources\views/superadmin/subscription/subscriptioncreate.blade.php ENDPATH**/ ?>