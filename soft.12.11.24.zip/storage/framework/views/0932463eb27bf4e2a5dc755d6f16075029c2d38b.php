
<?php $__env->startSection('title'); ?>
    <title>Subscriber Registration Form | Nurjahan Bazar</title>
<?php $__env->stopSection(); ?>




<?php if(auth()->user()->is_admin == 1): ?>
    <script>window.location = "<?php echo e(route('admin.home')); ?>";</script>
<?php elseif(auth()->user()->is_admin == 2): ?>
    <script>window.location = "<?php echo e(route('subadmin.home')); ?>";</script>
<?php endif; ?>





<?php echo $__env->make('Member.Member_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Server_7.4\htdocs\nurjahansoft\14.10.24\resources\views/home.blade.php ENDPATH**/ ?>