
<?php $__env->startSection('title'); ?>
    <title>Dashboard | Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <section class='statis text-center content'>
        <div class="container-fluid">
            

            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            



            

            <div class="row">
                <?php if(Auth::user()->is_admin=='2'): ?>
                <div class="col-md-4">
                    <div class="box bg-primary">
                        <a href="<?php echo e(route('admin.paidsubscriberlist')); ?>">
                            <i class="fa fa-user-o"></i>
                            <h3><?php echo e($subscriberlist); ?></h3>
                            <p class="lead">Total Subscriber</p>
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box danger">
                        <a href="<?php echo e(route('nonsub.userlist')); ?>">
                            <i class="fa fa-user-o"></i>
                            <h3><?php echo e($nonsubscriberlist); ?></h3>
                            <p class="lead">Total Non Subscriber</p>
                        </a>


                    </div>
                </div>
                <div class="col-md-4">
                    <div class="box warning">
                        <a href="<?php echo e(route('admin.pendinglist')); ?>">
                            <i class="fa fa-user-o"></i>
                            <h3><?php echo e($pendinglist); ?></h3>
                            <p class="lead">Total Pending Subscriber</p>
                        </a>

                    </div>
                </div>

<?php else: ?>
                    <div class="col-md-4">
                        <div class="box bg-primary">
                            <a href="<?php echo e(route('admin.paidsubscriberlist')); ?>">
                                <i class="fa fa-user-o"></i>
                                <h3><?php echo e($subscriberlist); ?></h3>
                                <p class="lead">Total Subscriber</p>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box danger">
                            <a href="<?php echo e(route('nonsub.userlist')); ?>">
                                <i class="fa fa-user-o"></i>
                                <h3><?php echo e($nonsubscriberlist); ?></h3>
                                <p class="lead">Total Non Subscriber</p>
                            </a>


                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="box warning">
                            <a href="<?php echo e(route('admin.pendinglist')); ?>">
                                <i class="fa fa-user-o"></i>
                                <h3><?php echo e($pendinglist); ?></h3>
                                <p class="lead">Total Pending Subscriber</p>
                            </a>

                        </div>
                    </div>
                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-times"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Rejected</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.rejectedlist')); ?>">Rejected List</a></p>
                        </div>
                    </div>
                </div>

                    <div class="col-md-3">
                        <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-newspaper-o"></i>
                </span>
                            <div class="text-box">
                                <p class="main-text">Notice</p>
                                <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.notice')); ?>">Notice</a></p>
                            </div>
                        </div>
                    </div>


                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-money"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Sub.</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.subscription.fee')); ?>">Subscription fee</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-brown set-icon">
                    <i class="fa fa-users"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Seminar</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.seminar')); ?>">Seminar</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-green set-icon">
                    <i class="fa fa-newspaper-o"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Reports</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.report')); ?>">Reports</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-blue set-icon">
                    <i class="fa fa-cog"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Admin</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.settings')); ?>">Admin</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-brown set-icon">
                    <i class="fa fa-user-plus"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Admin</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('admin.userlist')); ?>">All User</a></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="panel panel-back noti-box">
                <span class="icon-box bg-color-red set-icon">
                    <i class="fa fa-sign-out"></i>
                </span>
                        <div class="text-box">
                            <p class="main-text">Logout</p>
                            <p class="text-muted"><a style="text-decoration:none;" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Logout</a></p>
                        </div>
                    </div>
                </div>

                    <?php endif; ?>

            </div>


            
            
            
            
            
            
            
            
            
            

            
            

            
            


            
            
            

            
            
            

            
            
            
            
            
            
            
            
            
            
            

            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            
            

            
            
            
            
            
            
            
            
            
            
            
            






        </div>
    </section>
<?php $__env->stopSection(); ?>

<style>

    .noti-box {
        min-height: 100px;
        padding: 20px;
    }
    .panel-back {
        background-color: #F8F8F8 !important;
    }
    .panel {
        margin-bottom: 20px;
        background-color: #fff;
        border: 1px solid transparent;
        border-radius: 4px;
        -webkit-box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
        box-shadow: 0 1px 1px rgba(0, 0, 0, .05);
    }
    .noti-box .icon-box {
        display: block;
        float: left;
        margin: 0 15px 10px 0;
        width: 70px;
        height: 70px;
        padding-top: 12px;
        line-height: 76px;
        vertical-align: middle;
        text-align: center;
        font-size: 45px;
    }
    .bg-color-red {
        background-color: #DB0630;
        color: #fff;
    }
    .bg-color-green {
        background-color: #00CE6F;
        color: #fff;
    }
    .bg-color-blue {
        background-color: #A95DF0;
        color: #fff;
    }
    .bg-color-brown {
        background-color: #B94A00;
        color: #fff;
    }
    .set-icon {
        -webkit-border-radius: 50px;
        -moz-border-radius: 50px;
        border-radius: 50px;
    }
    .bg-color-red {
        color: #fff;
    }
    .text-box p {
        margin: 0 0 3px;
        font-size: 16px;
        line-height: 25px;
        padding-top: 7px;
    }
    .main-text {
        font-size: 23px !important;
        font-weight: 600 !important;
    }
    .text-muted {
        color: #777;
    }
    .text-muted a {
        color: #4a4007;
    }
    /* Start statis */

    .statis {
        color: #EEE;
        margin-top: 15px;
    }
    .statis .box {
        position: relative;
        padding: 15px;
        overflow: hidden;
        border-radius: 3px;
        margin-bottom: 25px;
    }
    .box a {
        color: #fff;
    }
    .box a:hover{
        text-decoration: none;
        color: #222;
    }

    .box p {
        color: #fff;
    }
    .box h3 {
        color: #fff;
    }

    .statis .box h3:after {
        content: "";
        height: 2px;
        width: 70%;
        margin: auto;
        background-color: rgba(255, 255, 255, 0.12);
        display: block;
        margin-top: 10px;
    }
    .statis .box i {
        position: absolute;
        height: 70px;
        width: 70px;
        font-size: 22px;
        padding: 15px;
        top: -25px;
        left: -25px;
        background-color: rgba(255, 255, 255, 0.15);
        line-height: 60px;
        text-align: right;
        border-radius: 50%;
    }
    .panel p {
        color: #777777 !important;
        font-size: 14px;
        margin-bottom: 7px !important;
        line-height: 24px !important;
    }
    .warning {background-color: #f0ad4e}
    .danger {background-color: #d9534f}
    .success {background-color: #5cb85c}
    .inf {background-color: #5bc0de}
</style>
<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\14.3.22\resources\views/superadmin/dashboard.blade.php ENDPATH**/ ?>