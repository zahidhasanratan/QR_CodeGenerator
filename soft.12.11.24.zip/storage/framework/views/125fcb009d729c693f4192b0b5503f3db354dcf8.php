
<?php $__env->startSection('title'); ?>
    <title>Payment | Subscriber | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">


                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Payment</h4>
                            <!-- <p class="card-category">Complete your profile</p> -->
                        </div>


                        <div class="card-body">
                            <fieldset class="col-lg-12 border border-primary p-3 mb-3">
                                <legend class="w-25 text-center main-title"><small class="text-uppercase font-weight-bold "> </small></legend>

                                <div class="form-row">

                                <?php $__currentLoopData = $subscription_fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription_fees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12 mb-12 mb-6">

                                        

                                        <?php if(isset($subscription_fees_submit->userid)): ?>
                                            <?php if($subscription_fees_submit->userid === Auth::user()->id): ?>
                                                <div class="alert alert-info alert-info-custom">
                                                        <a href="#" class="btn btn-xs success pull-right btn-custom-payment">You are already paid subscriber</a>
                                                        1, <?php echo e($subscription_fees->title); ?> <strong style="color: #8e24aa; float: right; padding-right: 25px">  (<?php echo e($subscription_fees->fees); ?> Tk.)</strong>
                                                </div>
                                            <?php endif; ?>
                                            <?php else: ?>


                                        <div class="alert alert-info alert-info-custom">
                                            <a href="<?php echo e(route('Subscriber_payment_details','subscribe_details')); ?>" class="btn btn-xs danger pull-right btn-custom-payment">Pay Now</a>
                                            1, <?php echo e($subscription_fees->title); ?> <strong style="color: #8e24aa; float: right; padding-right: 25px">  (<?php echo e($subscription_fees->fees); ?> Tk.)</strong>
                                        </div>
                                        <?php endif; ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    <div class="col-md-12 mb-12 mb-6">
                                        <div class="alert alert-info alert-info-custom">
                                            <a href="#" class="btn btn-xs danger pull-right btn-custom-payment">Pay Now</a>
                                            2. Seminar On Big Data <strong style="color: #8e24aa; float: right; padding-right: 25px">  (2000 Tk.)</strong>

                                        </div>
                                    </div>

                                    <div class="col-md-12 mb-12 mb-6">
                                        <div class="alert alert-info alert-info-custom">
                                            <a href="#" class="btn btn-xs danger pull-right btn-custom-payment">Pay Now</a>
                                            <strong style="color: #8e24aa">3.</strong> Subscription for 2020
                                        </div>
                                    </div>

                                </div>
                            </fieldset>
                        </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.subscriber', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xamp.7.4\htdocs\WE\24.1.21\Software\WE\resources\views/subscriber/Payment.blade.php ENDPATH**/ ?>