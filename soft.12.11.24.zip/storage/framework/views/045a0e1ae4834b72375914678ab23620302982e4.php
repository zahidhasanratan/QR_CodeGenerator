<div class="sidebar" data-color="purple" data-background-color="white" data-image="<?php echo e(asset('asset/assets/img/sidebar-1.jpg')); ?>">
    <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
    <div class="logo">
        <a href="<?php echo e(route('subscriber-dashboard')); ?>" class="simple-text logo-normal">
            <img src="<?php echo e(asset('asset/images/logo.png')); ?>">
        </a>
    </div>

    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item <?php if(Request::path() =='admin/home'): ?>
                    active
                <?php endif; ?>">
                <a class="nav-link" href="<?php echo e(route('admin.home')); ?>">
                    <i class="material-icons">dashboard</i>
                    <p>Dashboard</p>
                </a>
            </li>

            <!--  <li class="nav-item ">
               <a class="nav-link" href="personal-information.html">
                 <i class="material-icons">language</i>
                 <p>Personal Information</p>
               </a>
             </li> -->


            <li class="nav-item ">
                <a class="nav-link" href="#">
                    <i class="material-icons">language</i>
                    <p>Subscribers  </p>
                </a>
                <ul class="submenu-super">
                    <li class="nav-item <?php if(Request::path() =='admin/subscriber/subscriberlist'): ?>
                            active
                        <?php endif; ?>" ><a href="<?php echo e(route('admin.subscriberlist')); ?>">Subscriber List</a></li>
                    <li class="nav-item <?php if(Request::path() =='admin/subscriber/pendinglist'): ?>
                        active
                        <?php endif; ?>"><a href="<?php echo e(route('admin.pendinglist')); ?>">Pending Subscriber</a></li>
                    <li class="nav-item <?php if(Request::path() =='admin/subscriber/rejectedlist'): ?>
                            active
                            <?php endif; ?>">
                        <a href="<?php echo e(route('admin.rejectedlist')); ?>">Rejected List </a>
                    </li>


                    <li class="nav-item <?php if(Request::path() =='admin/subscriber/paidsubscriberlist'): ?>
                            active
                        <?php endif; ?>"><a href="<?php echo e(route('admin.paidsubscriberlist')); ?>">Paid Subscriber List</a></li>
                    <li><a href="#">Subscriber Certificate </a></li>
                    
                    <li><a href="#">Sms or Email </a></li>
                    <li><a href="#">Online Help Desk </a></li>
                    <li><a href="#">Payment </a></li>
                    <li class="nav-item <?php if(Request::path() =='admin/subscriber/notice'): ?>
                            active
                        <?php endif; ?>"><a href="<?php echo e(route('admin.notice')); ?>">Notice</a>
                    </li>

                </ul>
            </li>




            <li class="nav-item ">
                <a class="nav-link" href="seminar-workshop.html">
                    <i class="material-icons">language</i>
                    <p>Services </p>
                </a>

                <ul class="submenu-super">
                    <li><a href="<?php echo e(route('subscription.fees')); ?>">Subscription Fee</a></li>
                    <li><a href="#">Service List</a></li>
                    <li><a href="#">Service Approved</a></li>
                    <li><a href="#">Service Request </a></li>

                    <li><a href="<?php echo e(route('admin.seminar')); ?>">Training/ Seminar/ Workshop</a></li>

                </ul>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="change-request.html">
                    <i class="material-icons">language</i>
                    <p>Reports</p>
                </a>
                <ul class="submenu-super">
                    <li><a href="#">Total Subscriber Reports </a></li>
                    <li><a href="#">Subscriber Dues </a></li>
                    <li><a href="#">Total Female Employee </a></li>
                    <li><a href="#">Service/ Product wise </a></li>
                    <li><a href="#">District wise Subscriber </a></li>
                    <li><a href="#">Average Annual Income </a></li>
                    <li><a href="#">Total Sales from WE </a></li>
                    <li><a href="#">Monthly Sales from WE </a></li>
                    <li><a href="#">Search Reference </a></li>
                    <li><a href="#">Payment Reeipt  </a></li>

                </ul>

            </li>




            <li class="nav-item ">
                <a class="nav-link" href="#">
                    <i class="material-icons">language</i>
                    <p>logout</p>
                </a>
            </li>


            <!-- <li class="nav-item active-pro ">
              <a class="nav-link" href="./upgrade.html">
                <i class="material-icons">unarchive</i>
                <p>logout</p>
              </a>
            </li> -->
        </ul>
    </div>

</div><?php /**PATH H:\xamp.7.4\htdocs\WE\3.3.21\resources\views/layouts/partial/super/sidebar.blade.php ENDPATH**/ ?>