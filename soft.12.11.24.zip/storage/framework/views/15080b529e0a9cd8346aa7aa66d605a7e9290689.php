
<?php $__env->startSection('title'); ?>
    <title>Subscriber Certificate List | Super Admin | Women & e-Commerce</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="flash-message">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has('alert-' . $msg)): ?>
                            <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card">
                    <div class="card-header card-header-primary">
                        <h4 class="card-title">Paid List for <?php echo e(\App\Models\Seminar::where(['id' => $id])->pluck('title')->first()); ?></h4>
                        <!-- <p class="card-category">Complete your profile</p> -->
                    </div>
                    <div class="card-body">

                        
                        
                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                            <tr>
                                <th>Sl</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Amount</th>


                                <th width="40%">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $paid_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$paid_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>1</td>
                                    <td><?php echo e($paid_list->name); ?></td>
                                    <td><?php echo e($paid_list->email); ?></td>
                                    <td><?php echo e($paid_list->amount); ?></td>


                                    <td>
                                        <a target="_blank" href="<?php echo e(route('seminar.paid.details',$paid_list->userid)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i> View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tfoot>
                        </table>
                    </div>


                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.superadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\server\htdocs\WE\26.3.21export\26.3.21\resources\views/superadmin/seminar/certi_list.blade.php ENDPATH**/ ?>