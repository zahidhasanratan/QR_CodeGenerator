Hello <?php echo e($email_data['name']); ?>

<br><br>
You have been successfully varified!
<br>

Please <a href="<?php echo e(route('nonSubscriber_subscription_details',$email_data['subscription_id'])); ?>">Click Here to Make Payment</a>







<br><br>
Thank you!
<br>
weforumbd.org<?php /**PATH H:\xamp.7.4\htdocs\WESOFTWARE\8.3.22\resources\views/mail/activeEmail.blade.php ENDPATH**/ ?>